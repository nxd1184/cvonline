export const environment = {
  production: true,
  API: 'http://18.184.238.147:5000'
};
