import { Component } from '@angular/core';

@Component({
  selector: 'app-error5',
  templateUrl: './error5.component.html',
  styleUrls: ['./error5.component.scss']
})
export class Error5Component { }
