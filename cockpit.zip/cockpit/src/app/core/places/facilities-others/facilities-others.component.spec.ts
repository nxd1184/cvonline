import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FacilitiesOthersComponent } from './facilities-others.component';

describe('FacilitiesOthersComponent', () => {
  let component: FacilitiesOthersComponent;
  let fixture: ComponentFixture<FacilitiesOthersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FacilitiesOthersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FacilitiesOthersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
