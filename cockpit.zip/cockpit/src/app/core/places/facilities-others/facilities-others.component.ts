import { Component, OnInit, Input } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { CoreProviderService } from '../../../services/core-provider.service';

@Component({
  selector: 'app-facilities-others',
  templateUrl: './facilities-others.component.html',
  styleUrls: ['./facilities-others.component.scss']
})
export class FacilitiesOthersComponent implements OnInit {

  allFacilities = [];
  allAmbiances = [];
  allSpecialties = [];

  activeSpecialties = [];
  activeAmbiances = [];
  activeFacilities = [];
  
  constructor(
    public translate: TranslateService, 
    private coreProviderService: CoreProviderService
  ) { }


  ngOnInit() {
    this.coreProviderService.getMockFacilities().subscribe(facilities => {
      this.allFacilities = facilities;
      this.allAmbiances = facilities;
      this.allSpecialties = facilities;
    });
  }

  addFacility = (facility) => {
    let activeFacilities = this.activeFacilities.slice();
    activeFacilities.push(facility);
    this.activeFacilities = activeFacilities;
  }

  removeFacility = (facility) => {
    let index = -1;
    this.activeFacilities.find((f,key) => {
      if(f.id === facility.id){
        index=key;
        return true;
      }
      return false;
    })

    if(index !== -1){
      let activeFacilities = this.activeFacilities.slice();
      activeFacilities.splice(index,1);
      this.activeFacilities = activeFacilities;
    }
  }

  addAmbiance = (ambiance) => {
    let activeAmbiances = this.activeAmbiances.slice();
    activeAmbiances.push(ambiance);
    this.activeAmbiances = activeAmbiances;
  }

  removeAmbiance = (ambiance) => {
    let index = -1;
    this.activeAmbiances.find((f,key) => {
      if(f.id === ambiance.id){
        index=key;
        return true;
      }
      return false;
    })

    if(index !== -1){
      let activeAmbiances = this.activeAmbiances.slice();
      activeAmbiances.splice(index,1);
      this.activeAmbiances = activeAmbiances;
    }
  }

  addSpecialty = (specialty) => {
    let activeSpecialties = this.activeSpecialties.slice();
    activeSpecialties.push(specialty);
    this.activeSpecialties = activeSpecialties;
  }

  removeSpecialty = (specialty) => {
    let index = -1;
    this.activeSpecialties.find((f,key) => {
      if(f.id === specialty.id){
        index=key;
        return true;
      }
      return false;
    })

    if(index !== -1){
      let activeSpecialties = this.activeSpecialties.slice();
      activeSpecialties.splice(index,1);
      this.activeSpecialties = activeSpecialties;
    }
  }

  save = () => {
    console.log('save');
  }
}
