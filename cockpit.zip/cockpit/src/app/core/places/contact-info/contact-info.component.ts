import {Component, OnInit} from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import {TenantService} from '../../../services/tenant.service';
import {Tenant} from '../../../models/tenant.model';
import {FormControl, FormGroup} from '@angular/forms';
import {Router} from '@angular/router';
import {PlaceService} from '../../../services/place.service';

@Component({
  selector: 'app-contact-info',
  templateUrl: './contact-info.component.html',
  styleUrls: ['./contact-info.component.scss'],
  providers: [TenantService]
})
export class ContactInfoComponent implements OnInit {
  tenantForm: FormGroup;



  constructor(public translate: TranslateService,
              private tenantService: TenantService,
              public placeService: PlaceService,
              private router: Router) {}
  ngOnInit() {

    this.tenantForm = new FormGroup({
      tenancy_name: new FormControl(),
      owner_name: new FormControl(),
      phone_code: new FormControl(),
      phone_number: new FormControl(),
      email: new FormControl()
    });

    this.placeService.removeTenant();
  }

  onSubmit() {
    const tenant = new Tenant().fromJson(this.tenantForm.value);
    this.tenantService.createTenant(tenant).subscribe(rs => {
      this.placeService.tenant = rs;
      this.router.navigate(['places', 'generalinfo']);
    });
  }
}
