import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

const ELEMENTS = [
  {
    key: 'CONTACT_INFO',
    text: 'PLACE.CONTACT_INFO',
    icon: 'test.png',
    route: 'contactinfo'
  },
  {
    key: 'GENERAL_INFO',
    text: 'PLACE.GENERAL_INFO',
    icon: 'test.png',
    route: 'generalinfo'
  },
  {
    key: 'FACILITIES_OTHERS',
    text: 'PLACE.FACILITIES_OTHERS',
    icon: 'test.png',
    route: 'facilitiesandothers'
  },
  {
    key: 'PHOTOS',
    text: 'PLACE.PHOTOS',
    icon: 'test.png',
    route: 'photos'
  },
  {
    key: 'DISHES',
    text: 'PLACE.DISHES',
    icon: 'test.png',
    route: 'dishes',
    children: [
      {
        key: 'MENU_PHOTOS',
        text: 'PLACE.MENU_PHOTOS',
        icon: 'test.png',
        route: 'menuphotos'
      },
      {
        key: 'DISHES',
        text: 'PLACE.DISHES',
        icon: 'test.png',
        route: 'dishes'
      },
      {
        key: 'MENU',
        text: 'PLACE.MENU',
        icon: 'test.png',
        route: 'menu'
      }
    ]
  },
  {
    key: 'LEGAL',
    text: 'PLACE.LEGAL',
    icon: 'test.png',
    route: 'legal'
  },
  {
    key: 'COMPLETE',
    text: 'PLACE.COMPLETE',
    icon: 'test.png',
    route: 'complete'
  },
]

@Component({
  selector: 'app-places-toolbar',
  templateUrl: './places-toolbar.component.html',
  styleUrls: ['./places-toolbar.component.scss']
})

export class PlacesToolbarComponent {

  constructor(public translate: TranslateService) { }
  
  elements = ELEMENTS;
}
