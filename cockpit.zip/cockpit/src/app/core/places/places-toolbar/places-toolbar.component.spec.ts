import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlacesToolbarComponent } from './places-toolbar.component';

describe('PlacesToolbarComponent', () => {
  let component: PlacesToolbarComponent;
  let fixture: ComponentFixture<PlacesToolbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlacesToolbarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlacesToolbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
