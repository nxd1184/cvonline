import { Component, OnInit, ViewChild, TemplateRef, ViewContainerRef, OnDestroy } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CoreProviderService } from '../../../services/core-provider.service';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { DragulaService } from 'ng2-dragula';

declare var $;
@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss']
})
export class MenuComponent implements OnInit, OnDestroy {
  @ViewChild(DatatableComponent) tableDishes: DatatableComponent;
  @ViewChild('viewDishTemplate') viewDishTemplate: TemplateRef<any>;
  @ViewChild('editDishTemplate') editDishTemplate: TemplateRef<any>;
  @ViewChild('deleteDishTemplate') deleteDishTemplate: TemplateRef<any>;
  langs = [
    { name: 'English', img: 'en' },
    { name: 'French', img: 'fr' },
    { name: 'Dutch', img: 'de' },
    { name: 'Vietnamese', img: 'vi' }
  ];
  courseNames: any[];
  divLangs = [{ name: 'English', img: 'en' }];
  selectedLang: any;
  offset = 0;
  limit = 10;
  dishes = [];
  courses = [];
  isCollapsed: any;
  count = 0;
  columnsCourseAccordion: any;
  columnsAddDishesModal: any;
  tempDishes: any[];
  cuisines: any;

  constructor(private modalService: NgbModal, private dragulaService: DragulaService, private coreProviderService: CoreProviderService) {
    dragulaService.setOptions('bag-course', {
      moves: function (el, container, handle) {
        return handle.className === 'fa fa-bars handle';
      }
    });
  }

  ngOnInit() {
    this.selectedLang = this.langs[0];
    this.columnsCourseAccordion = [
      { name: 'DishId', prop: 'id' },
      { name: 'Name', prop: 'name' },
      { name: 'Price', prop: 'price' },
      { name: 'Cuisine', prop: 'cuisine' },
      { name: '', prop: 'viewDish', cellTemplate: this.viewDishTemplate, width: 30 },
      { name: '', prop: 'editDish', cellTemplate: this.editDishTemplate, width: 30 },
      { name: '', prop: 'deleteDish', cellTemplate: this.deleteDishTemplate, width: 30 }
    ];
    this.columnsAddDishesModal = [
      { name: 'DishId', prop: 'id' },
      { name: 'Name', prop: 'name' },
      { name: 'Price', prop: 'price' },
      { name: 'Cuisine', prop: 'cuisine' },
      {
        prop: 'selected',
        name: '',
        sortable: false,
        canAutoResize: false,
        draggable: false,
        resizable: false,
        headerCheckboxable: true,
        checkboxable: true,
        width: 30
      }
    ];
    this.getCourses();
    this.getDishes();
  }

  ngOnDestroy(): void {
    this.dragulaService.destroy('bag-course');
  }

  getCourses() {
    this.coreProviderService.getMockCourses().subscribe(courses => {
      this.courses = courses;
      this.courseNames = this.courses.map(course => course.name);
      this.isCollapsed = Array(this.courses.length).fill(true);
    });
  }

  editCourse(courseId) {
    // TODO
  }

  cloneDivLanguage() {
    this.divLangs.push({ name: 'English', img: 'en' });
  }

  deleteCourse(courseId) {
    this.courses = this.courses.filter(course => course.id !== courseId);
  }
  getRowClass(row) {
    return 'datatable-custom-row';
  }

  getDishes() {
    this.coreProviderService.getMockDishes().subscribe(dishes => {
      this.dishes = dishes;
      this.tempDishes = [...dishes];
    });
  }

  open(modal) {
    this.modalService.open(modal, { centered: true, size: 'lg' });
  }

  updateFilter(event) {
    const val = event.target.value.toLowerCase();
    const temp = this.dishes.filter(function (d) {
      return d.name.toLowerCase().indexOf(val) !== -1 || d.id.toLowerCase().indexOf(val) !== -1 || !val;
    });
    this.tempDishes = temp;
    this.tableDishes.offset = 0;
  }

  viewDish(courseId) {
    // TODO
  }
  editDish(row) {
    // TODO
  }
  deleteDish(row) {
    // TODO
  }
}
