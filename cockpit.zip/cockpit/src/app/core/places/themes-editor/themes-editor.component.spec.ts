import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThemesEditorComponent } from './themes-editor.component';

describe('ThemesEditorComponent', () => {
  let component: ThemesEditorComponent;
  let fixture: ComponentFixture<ThemesEditorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThemesEditorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThemesEditorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
