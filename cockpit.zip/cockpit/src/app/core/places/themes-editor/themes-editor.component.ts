import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';


interface Element {
  id: string;
  text: string;
}

@Component({
  selector: 'app-themes-editor',
  templateUrl: './themes-editor.component.html',
  styleUrls: ['./themes-editor.component.scss']
})
export class ThemesEditorComponent implements OnChanges{

  constructor(public translate: TranslateService) {}

  @Input() title: string;
  @Input() nbEleDisplay: Number;
  @Input() activeElements: Array<Element>;
  @Input() allElements: Array<Element>;
  @Output() addElement: EventEmitter<any> = new EventEmitter();
  @Output() removeElement: EventEmitter<any> = new EventEmitter();

  ngOnChanges(changes: SimpleChanges) {
    if(changes.activeElements || changes.allElements){
      this.setElementShow();
    }
  }

  searchText = '';
  
  search = () =>{
    this.setElementShow();
  }

  elementsShown = [];
  nbInvisibleEle = 0;
  isShowAll = false;

  setElementShow = () => {
    const otherElements = this.allElements.filter(e => !this.isActiveElement(e));
    let elementsShown = this.activeElements.concat(otherElements);

    if(this.searchText){
      const regex = new RegExp(this.searchText, 'i');
      elementsShown = elementsShown.filter(e => e.text.search(regex) !== -1);
    }
    
    if(!this.isShowAll){
      let nb;
      const nbEleDisplay = this.nbEleDisplay.valueOf(),
            nbELement = elementsShown.length;
      if( nbEleDisplay < nbELement){
        nb = nbEleDisplay;
        this.nbInvisibleEle = nbELement - nbEleDisplay;
      }else{
        nb = nbELement;
        this.nbInvisibleEle = 0;
      }
      elementsShown = elementsShown.slice(0, nb);
    }

    this.elementsShown = elementsShown;
  }

  isActiveElement = (ele) => {
    const foundEle = this.activeElements.find(e => e.id === ele.id);
    if(foundEle){
      return true;
    }
    return false;
  }

  showMore = () => { 
    this.isShowAll = true;
    this.setElementShow();
  };

  showLess = () =>{ 
    this.isShowAll = false;
    this.setElementShow();
  };


}
