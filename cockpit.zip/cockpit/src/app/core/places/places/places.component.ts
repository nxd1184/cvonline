import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-places',
  templateUrl: './places.component.html',
  styleUrls: ['./places.component.scss']
})
export class PlacesComponent {

  hasPlacesToolbar: boolean;

  constructor(public translate: TranslateService, private router: Router) { 
    this.router.events.subscribe((events) => {
      if (events instanceof NavigationEnd) {
        if (events.url === '/places') {
          this.hasPlacesToolbar = false;
        } else {
          this.hasPlacesToolbar = true;
        }
      }
    });
  }
}
