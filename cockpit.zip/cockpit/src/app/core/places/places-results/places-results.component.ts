import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { CoreProviderService } from '../../../services/core-provider.service';
import { DatatableComponent } from '@swimlane/ngx-datatable';

@Component({
  selector: 'app-places-results',
  templateUrl: './places-results.component.html',
  styleUrls: ['./places-results.component.scss']
})
export class PlacesResultsComponent implements OnInit {
  @ViewChild('statusTemplate') statusTemplate: TemplateRef<any>;
  @ViewChild('ellipsisTemplate') ellipsisTemplate: TemplateRef<any>;
  @ViewChild(DatatableComponent) tablePlaces: DatatableComponent;
  offset = 0;
  limit = 10;
  places = [];
  count = 0;
  columns: any;
  cities = ['None', 'None', 'None', 'None'];
  types = ['None', 'None', 'None', 'None'];
  cuisines = ['None', 'None', 'None', 'None'];
  prices = ['None', 'None', 'None', 'None'];
  specialties = ['None', 'None', 'None', 'None'];
  ambiances = ['None', 'None', 'None', 'None'];
  orders = ['Last Added', 'First Added'];
  statusList = ['All', 'Activated', 'Deactivated', 'Drafting'];
  sttColor = ['red', 'blue', 'green', 'yellow'];
  constructor(private coreProviderService: CoreProviderService) { }

  ngOnInit() {
    this.columns = [
      { name: 'PlaceID', prop: 'id' },
      { name: 'Name', prop: 'name' },
      { name: 'City', prop: 'city' },
      { name: 'Type', prop: 'type' },
      { name: 'Cuisines', prop: 'cuisines' },
      { name: 'Price range', prop: 'price' },
      { name: 'Specialty', prop: 'specialty' },
      { name: 'Date added', prop: 'date_added' },
      { name: 'Status', prop: 'status', width: 180, cellTemplate: this.statusTemplate },
      { name: '', prop: 'ellipsis', cellTemplate: this.ellipsisTemplate }
    ];
    this.getPlaces();
  }

  getPlaces() {
    this.coreProviderService.getMockPlaces().subscribe(places => {
      this.places = places;
    });
  }

  updateFilter() {
    const status = 'In app';
    const temp = this.places.filter(place => place.status === status);
    this.places = temp;
    this.tablePlaces.offset = 0;
  }
}
