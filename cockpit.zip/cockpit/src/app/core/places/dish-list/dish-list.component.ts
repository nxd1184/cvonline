import { Component, OnInit, ViewChild } from '@angular/core';
import { TranslateService } from '../../../../../node_modules/@ngx-translate/core';

import {NgbModal} from '@ng-bootstrap/ng-bootstrap';

import { FileUploader } from 'ng2-file-upload/ng2-file-upload';
import {FormArray, FormArrayName, FormBuilder, FormControl, FormGroup} from '@angular/forms';
import {CookingMethod, Cuisine, Currency, DishType, ExtraInfo, Ingredient} from '../../../models/core-provider.model';
import {CoreProviderService} from '../../../services/core-provider.service';
import {SearchOption} from '../../../models/SearchOption';
import {Dish} from '../../../models/dish.model';
import {DishService} from '../../../services/dish.service';

const URL = '';

const PHOTOS = [
  {
    id : '0',
    url : 'assets/images/logos/angular.png'
  }
];


const COLUMN = [
  {
    key : 'id',
    text : 'DISHES.DISHID'
  },
  {
    key : 'name',
    text : 'DISHES.NAME'
  },
  {
    key : 'price',
    text : 'DISHES.PRICE'
  },
  {
    key : 'cuisine',
    text : 'DISHES.CUISINE'
  },
  {
    key : 'ingredients',
    text : 'DISHES.INGREDIENTS'
  }
];

@Component({
  selector: 'app-dish-list',
  templateUrl: './dish-list.component.html',
  styleUrls: ['./dish-list.component.scss'],
  providers: [DishService]
})
export class DishListComponent implements OnInit {

  orders = ['Last Added', 'First Added'];
  table_dishes_header = COLUMN;
  dishes = [];

  closeResult: string;

  cuisines: Cuisine[];
  selectedCuisins = [];

  ingredients: Ingredient[];
  selectedIngredients = [];

  extraInfos: ExtraInfo[];
  cookingMethods: CookingMethod[];

  dishTypes: DishType[];

  langs = ['En', 'Fr', 'De', 'Vi'];

  languages = ['En'];
  currency = ['USD', 'VND', 'EUR'];
  currencies: Currency[];
  photos = PHOTOS;

  uploader: FileUploader = new FileUploader({
    url: URL,
    isHTML5: true
  });

  createDishForm: FormGroup;
  searchOption: SearchOption = new SearchOption();
  descriptions: FormArray;

  @ViewChild('contentConfirm') contentConfirm;

  constructor(
    public translate: TranslateService,
    private modalService: NgbModal,
    private coreProviderService: CoreProviderService,
    private fb: FormBuilder,
    private dishService: DishService
  ) { }

  ngOnInit() {
    // this.dishes = this.dishesService.getDishes();

    this.createDishForm = this.fb.group({
      name: '',
      descriptions: this.fb.array([this.createDescriptionItem()]),
      ingredient_ids: [],
      extra_info_ids: [],
      cooking_method_ids: [],
      dish_type_ids: [],
      cuisine_ids: [],
      // prices: [this.fb.array([this.createPriceItem])]
    });

    this.searchOption.limit = 1000;
    this.searchOption.allLanguage = false;

    this.coreProviderService.getCuisines(this.searchOption).subscribe(rs => {
      this.cuisines = rs[1];
    });

    this.coreProviderService.getIngredients(this.searchOption).subscribe(rs => {
      this.ingredients = rs[1];
    });

    this.coreProviderService.getExtraInfo(this.searchOption).subscribe(rs => {
      this.extraInfos = rs[1];
    });

    this.coreProviderService.getDishTypes(this.searchOption).subscribe(rs => {
      this.dishTypes = rs[1];
    });

    this.coreProviderService.getCookingMethods(this.searchOption).subscribe(rs => {
      this.cookingMethods = rs[1];
    });

    this.coreProviderService.getCurrencies(this.searchOption).subscribe(rs => {
      this.currencies = rs[1];
    });

    }

    createMethodItem(): FormControl {
      return this.fb.control('');
    }

    createDescriptionItem(): FormGroup {
      return this.fb.group({
        language: '',
        value: ''
      });
    }

  addDescription(): void {
    this.descriptions = this.createDishForm.get('descriptions') as FormArray;
    this.descriptions.push(this.createDescriptionItem());
  }

  createPriceItem(): FormGroup {
    return this.fb.group({
      currency_id: '',
      price: ''
    });
  }

  viewDetail = (index) => {
    console.log('view detail: ', index);
  }

  edit = (index) => {
    console.log('edit: ', index);
  }

  delete = (index) => {
    console.log('delete: ', index);
    this.dishes.splice(index, 1);
  }

  open(content) {
    this.modalService.open(content, { size: 'lg' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.openConfirm(content);
    });
  }

  openConfirm(content) {
    this.modalService.open(this.contentConfirm, { size: 'lg' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.open(content);
    });
  }

  addDivLanguage() {
    this.languages.push('En');
  }

  dropFile = (files) => {
    console.log(files);
    if (files[0].type.indexOf('image') !== -1) {
      this.photos.push({
        id : `${this.photos.length}`,
        url : 'assets/images/logos/angular.png'
      });
    }
  }

  upload = (ev) => {
    if (ev.target.files) {
      this.dropFile(ev.target.files);
    }
  }

  delete_photo = (index) => {
    this.photos.splice(index, 1);
  }

  save = () => {
    console.log('save', this.createDishForm.value);
    const formData = this.createDishForm.value;
    const dish = new Dish().fromJson(formData);

    this.dishService.createDish(1, dish)
      .subscribe(rs => {
        // this.placeService.restaurant = rs;
      });
  }

}
