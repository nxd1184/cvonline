import { Component, OnInit, ViewChild } from '@angular/core';
import { TranslateService } from '../../../../../node_modules/@ngx-translate/core';
import { DishesService} from './dishes.service';

import {NgbModal} from '@ng-bootstrap/ng-bootstrap';

import { FileUploader } from 'ng2-file-upload/ng2-file-upload';

const URL = '';

const PHOTOS = [
  {
    id : "0",
    url : "assets/images/logos/angular.png"
  }
];


const COLUMN = [
  {
    key : "id",
    text : "DISHES.DISHID"
  },
  {
    key : "name",
    text : "DISHES.NAME"
  },
  {
    key : "price",
    text : "DISHES.PRICE"
  },
  {
    key : "cuisine",
    text : "DISHES.CUISINE"
  },
  {
    key : "ingredients",
    text : "DISHES.INGREDIENTS"
  }
]

@Component({
  selector: 'app-dish-list',
  templateUrl: './dish-list.component.html',
  styleUrls: ['./dish-list.component.scss'],
  providers: [DishesService]
})
export class DishListComponent implements OnInit {
  
  orders = ['Last Added', 'First Added'];
  table_dishes_header = COLUMN;
  dishes = [];

  closeResult: string;

  cuisines = ['Asian', 'Thai', 'Viet', 'Phap', 'Trung'];
  selectedCuisins = [];
  ingredients = ["Chicken", "Curry", "Cocount milk"];
  selectedIngredients = [];
  langs = ['En', 'Fr', 'De', 'Vi'];

  languages = ['En'];

  currency = ["USD", "VND", "EUR"]
  
  photos = PHOTOS;

  uploader: FileUploader = new FileUploader({
    url: URL,
    isHTML5: true
  });

  @ViewChild('contentConfirm') contentConfirm;

  constructor(
    public translate: TranslateService,
    public dishesService : DishesService,
    private modalService: NgbModal
  ) { }

  ngOnInit() {
    this.dishes = this.dishesService.getDishes();
  }
  
  viewDetail = (index) => {
    console.log("view detail: ", index);
  }
  
  edit = (index) => {
    console.log("edit: ", index);
  }

  delete = (index) => {
    console.log("delete: ", index);
    this.dishes.splice(index,1);
  }

  open(content) {
    this.modalService.open(content, { size: 'lg' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.openConfirm(content);
    });
  }

  openConfirm(content){
    this.modalService.open(this.contentConfirm, { size: 'lg' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.open(content);
    });
  }

  addDivLanguage() {
    this.languages.push('En');
  }
  
  dropFile = (files) => {
    console.log(files);
    if(files[0].type.indexOf("image") !== -1){
      this.photos.push({
        id : `${this.photos.length}`,
        url : "assets/images/logos/angular.png"
      })
    }
  }

  upload = (ev) => {
    if(ev.target.files){
      this.dropFile(ev.target.files);
    }
  }

  delete_photo = (index) => {
    this.photos.splice(index,1);
  }

  save = () => {
    console.log("save");
  }

}
