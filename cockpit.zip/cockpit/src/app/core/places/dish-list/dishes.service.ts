import { Injectable } from '@angular/core';

export interface Dish {
  id: string;
  name: string;
  price: string;
  cuisine: string;
  ingredients: string
}

const DISHES: Dish[] = [
    {
        id: "1",
        name: "Tom Kha Gai",
        price: "15 CHF",
        cuisine: "Asian, Thai",
        ingredients: "Shrimps, Coconut Milk"
    },
    {
        id: "2",
        name: "Tom Kha Gai",
        price: "15 CHF",
        cuisine: "Asian, Thai",
        ingredients: "Shrimps, Coconut Milk"
    },
    {
        id: "3",
        name: "Tom Kha Gai",
        price: "15 CHF",
        cuisine: "Asian, Thai",
        ingredients: "Shrimps, Coconut Milk"
    },
    {
        id: "4",
        name: "Tom Kha Gai",
        price: "15 CHF",
        cuisine: "Asian, Thai",
        ingredients: "Shrimps, Coconut Milk"
    }
];

@Injectable()
export class DishesService {
  getDishes(): Dish[] {
    return DISHES;
  }
}
