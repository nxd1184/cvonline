import {Component, Input, OnInit} from '@angular/core';
import {FormGroup, FormArray, FormBuilder} from '@angular/forms';


@Component({
  selector: 'app-opening-hours',
  templateUrl: './opening-hours.component.html',
  styleUrls: ['./opening-hours.component.scss'],
  providers: []
})
export class OpeningHoursComponent implements OnInit {

  openingHoursGroup: FormGroup;

  @Input()
  dayOfWeek: string;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.openingHoursGroup = this.fb.group({
        selected: false,
        ranges: this.fb.array([this.createSpecificPeriod()])
    });
  }

  private createSpecificPeriod(): FormGroup {
    return this.fb.group({
      start: '',
      end: ''
    });
  }

  addRanges(): void {
    (this.openingHoursGroup
      .get('ranges') as FormArray)
      .push(this.createSpecificPeriod());
  }
}
