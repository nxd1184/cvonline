import { Injectable } from '@angular/core';

export interface Country {
  id: string;
  name: string;
}

export interface City {
  id: string;
  countryId: string;
  name: string;
}

export interface District {
  id: string;
  cityId: string;
  name: string;
}

const COUNTRIES: Country[] = [
  {
    id : "1",
    name : "Vietnam"
  },
  {
    id : "2",
    name : "USA"
  },
  {
    id : "3",
    name : "France"
  }
];

const CITIES: City[] = [
  {
    id : "1",
    countryId : "1",
    name : "Saigon"
  },
  {
    id : "2",
    countryId : "1",
    name : "Danang"
  },
  {
    id : "3",
    countryId : "2",
    name : "New York"
  },
  {
    id : "4",
    countryId : "3",
    name : "London"
  }
];

const DISTRICTS: District[] = [
  {
    id : "1",
    cityId : "1",
    name : "Quan 1"
  },
  {
    id : "2",
    cityId : "1",
    name : "Quan 2"
  },
  {
    id : "3",
    cityId : "3",
    name : "Manhattan"
  },
  {
    id : "4",
    cityId : "4",
    name : "Canning Town"
  }
];

@Injectable()
export class LocationService {
  getCountries(): Country[] {
    return COUNTRIES;
  }
  getCities(): City[] {
    return CITIES;
  }
  getDistricts(): District[] {
    return DISTRICTS;
  }
}
