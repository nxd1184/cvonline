import {Component, OnInit, ViewChild, ViewContainerRef, ComponentFactoryResolver, NgZone, ElementRef} from '@angular/core';
import {LocationService} from './location.service';
import {PlaceService} from '../../../services/place.service';
import {CoreProviderService} from '../../../services/core-provider.service';
import {Tenant} from '../../../models/tenant.model';
import {FormControl, FormGroup, FormArray, FormBuilder} from '@angular/forms';
import {SearchOption} from '../../../models/SearchOption';
import {Country, Cuisine, RestaurantType, City} from '../../../models/core-provider.model';
import {Restaurant} from '../../../models/restaurant.model';

const OPENING_OPTIONS = [
  {
    id: 'selected-hours',
    label: 'PLACE.OPEN_FOR_SELECTED_HOURS'
  },
  {
    id: 'always-open',
    label: 'PLACE.ALWAYS_OPEN'
  },
  {
    id: 'no-hours',
    label: 'PLACE.NO_HOURS_AVAILABLE'
  }
];

const DAYS = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'];
const EXTRA_INFO_OPTIONS_LABEL = ['FACEBOOK', 'TWITTER', 'LINKEDIN', 'WEBSITE'];
const LOCATION_LABEL = ['ZIPCODE', 'LONGTITUDE', 'LATITUDE'];

@Component({
  selector: 'app-general-info',
  templateUrl: './general-info.component.html',
  styleUrls: ['./general-info.component.scss'],
  providers: [LocationService]
})
export class GeneralInfoComponent implements OnInit {

  generalInformationGroup: FormGroup;

  restaurantTypes: RestaurantType[];
  cuisines: Cuisine[];
  introductions: FormArray;
  countries: Country[];
  cities: City[];
  filteredCities: City[];
  searchOption: SearchOption = new SearchOption();
  selectedHourOption: FormControl;

  @ViewChild('container', {read: ViewContainerRef}) container;
  currentRate = 3;
  langs = ['En', 'Fr', 'De', 'Vi'];

  // set google maps defaults
  zoom = 4;
  latitude = 39.8282;
  longitude = -98.5795;

  country = '';
  city = '';
  district = '';

  cityOptions = [];
  districtOptions = [];

  opening_options = OPENING_OPTIONS;
  opening_option = OPENING_OPTIONS[0].id;
  hoursOptions = [];

  extraInfo = [];
  locationOptions = [];

  test: Tenant;

  constructor(private resolver: ComponentFactoryResolver,
              private placeService: PlaceService,
              public locationService: LocationService,
              private coreProviderService: CoreProviderService,
              private fb: FormBuilder) {
  }

  ngOnInit(): void {

    // set current position
    this.setCurrentPosition();

    this.test = this.placeService.tenant;
    console.log('Tenant : ', this.test);

    this.searchOption.limit = 1000;
    this.searchOption.allLanguage = false;

    this.selectedHourOption = this.fb.control(this.opening_options[0].id);

    this.generalInformationGroup = this.fb.group({
      long_name: '',
      phone_number: '',
      email: '',
      price_level: 3,
      restaurant_type_ids: [],
      cuisine_ids: [],
      introductions: this.fb.array([this.createIntroduction()]),
      address: '',
      country_id: 0,
      city_id: 0,
      post_code: '',
      longitude: this.longitude,
      latitude: this.latitude,
      opening_hours: this.fb.group({
        is_specific_time: true,
        no_hours_available: false,
        hours: this.fb.group({
          monday: this.fb.group({
            selected: false,
            ranges: this.fb.array([this.createSpecificPeriod()])
          }),
          tuesday: this.fb.group({
            selected: false,
            ranges: this.fb.array([this.createSpecificPeriod()])
          }),
          webnesday: this.fb.group({
            selected: false,
            ranges: this.fb.array([this.createSpecificPeriod()])
          }),
          thursday: this.fb.group({
            selected: false,
            ranges: this.fb.array([this.createSpecificPeriod()])
          }),
          saturday: this.fb.group({
            selected: false,
            ranges: this.fb.array([this.createSpecificPeriod()])
          }),
          sunday: this.fb.group({
            selected: false,
            ranges: this.fb.array([this.createSpecificPeriod()])
          })
        })
      }),
      social_info: this.fb.group({
        facebook: '',
        instagram: '',
        website: '',
        linkedin: '',
        twitter: '',
        other: ''
      })
    });



    this.coreProviderService.getRestaurantTypes(this.searchOption).subscribe(rs => {
      this.restaurantTypes = rs[1];
    });

    this.coreProviderService.getCuisines(this.searchOption).subscribe(rs => {
      this.cuisines = rs[1];
    });

    this.coreProviderService.getCountries(this.searchOption).subscribe(rs => {
      this.countries = rs;
    });

    this.coreProviderService.getCities(this.searchOption).subscribe(rs => {
      this.cities = rs;
    });

    this.onChanges();
  }

  onChanges(): void {
    this.generalInformationGroup.get('longitude').valueChanges.subscribe(val => {
      this.longitude = Number(val);
    });

    this.generalInformationGroup.get('latitude').valueChanges.subscribe(val => {
      this.latitude = Number(val);
    });

    this.selectedHourOption.valueChanges.subscribe( val => {
      this.generalInformationGroup
        .get('opening_hours')
        .get('is_specific_time').setValue(this.selectedHourOption.value === this.opening_options[0].id);
      this.generalInformationGroup
        .get('opening_hours')
        .get('no_hours_available').setValue(this.selectedHourOption.value === this.opening_options[2].id);

    });
  }

  private createSpecificPeriod(): FormGroup {
    return this.fb.group({
      start: '',
      end: ''
    });
  }

  addRanges(dayOfWeek): void {
    (this.generalInformationGroup
        .get('opening_hours')
        .get('hours')
        .get('monday')
        .get('ranges') as FormArray)
            .push(this.createSpecificPeriod());
  }

  createIntroduction(): FormGroup {
    return this.fb.group({
      language: '',
      value: ''
    });
  }

  addIntroduction(): void {
    this.introductions = this.generalInformationGroup.get('introductions') as FormArray;
    this.introductions.push(this.createIntroduction());
  }

  onCountryChange($event) {
    this.generalInformationGroup.get('city_id').reset();
    this.filteredCities = this.cities.filter(city => city.country_id === $event.id);
  }

  private setCurrentPosition() {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        this.latitude = position.coords.latitude;
        this.longitude = position.coords.longitude;
        this.zoom = 12;
      });
    }
  }



  onSubmit() {
    const formData = this.generalInformationGroup.value;
    const restaurant = new Restaurant().fromJson(formData);

    console.log(restaurant);
  }
}
