import { Component, OnInit, ViewChild, ViewContainerRef, ComponentFactoryResolver, NgZone, ElementRef } from '@angular/core';
import { LocationService } from './location.service';
import {PlaceService} from '../../../services/place.service';
import {Tenant} from '../../../models/tenant.model';

const OPENING_OPTIONS = [
  {
    id: 'selected-hours',
    label: 'PLACE.OPEN_FOR_SELECTED_HOURS'
  },
  {
    id: 'always-open',
    label: 'PLACE.ALWAYS_OPEN'
  },
  {
    id: 'no-hours',
    label: 'PLACE.NO_HOURS_AVAILABLE'
  }
];

const DAYS = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'];
const EXTRA_INFO_OPTIONS_LABEL = ['FACEBOOK', 'TWITTER', 'LINKEDIN', 'WEBSITE'];
const LOCATION_LABEL = ['ZIPCODE', 'LONGTITUDE', 'LATITUDE'];
@Component({
  selector: 'app-general-info',
  templateUrl: './general-info.component.html',
  styleUrls: ['./general-info.component.scss'],
  providers: [LocationService]
})
export class GeneralInfoComponent implements OnInit {
  @ViewChild('clone') template;
  @ViewChild('container', { read: ViewContainerRef }) container;
  cuisines = ['Asian', 'Thai', 'Viet', 'Phap', 'Trung'];
  selectedCuisins = [];
  currentRate = 3;
  langs = ['En', 'Fr', 'De', 'Vi'];
  types = ['Fine Dining', 'Fine Dining', 'Fine Dining', 'Fine Dining'];

  // set google maps defaults
  zoom = 4;
  latitude = 39.8282;
  longitude = -98.5795;

  country = '';
  city = '';
  district = '';

  countryOptions = [];
  cityOptions = [];
  districtOptions = [];

  opening_options = OPENING_OPTIONS;
  opening_option = OPENING_OPTIONS[0].id;
  hoursOptions = [];

  extraInfo = [];
  locationOptions = [];

  test: Tenant;

  constructor(
    private resolver: ComponentFactoryResolver,
    private placeService: PlaceService,
    public locationService: LocationService
  ) { }

  ngOnInit(): void {
    this.cloneDivLanguage();
    this.setHoursOptions();
    this.setExtraInfo();
    this.setLocationOptions();

    // set current position
    this.setCurrentPosition();

    this.countryOptions = this.locationService.getCountries();
    this.test = this.placeService.tenant;
    console.log('Tenant : ', this.test);
  }

  private setCurrentPosition() {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        this.latitude = position.coords.latitude;
        this.longitude = position.coords.longitude;
        this.zoom = 12;
      });
    }
  }

  cloneDivLanguage() {
    this.container.createEmbeddedView(this.template);
  }

  setHoursOptions = () => {
    this.hoursOptions = DAYS.map(day => ({
      day: `DAYS.${day}`,
      isChecked: false,
      timeOptions:[
        {
          time_start: '',
          time_end: ''
        }
      ]
    }))
  }

  addTimeOption = (ele_index) => {
    this.hoursOptions[ele_index].timeOptions.push({
      time_start: '',
      time_end: ''
    })
  }

  duplicateHoursOption = (ele_index) => {
    let { isChecked, timeOptions } = this.hoursOptions[ele_index - 1];
    timeOptions = timeOptions.map(t => Object.assign({},t));
    this.hoursOptions[ele_index] = Object.assign(this.hoursOptions[ele_index], { isChecked, timeOptions });
  }

  setExtraInfo = () => {
    this.extraInfo = EXTRA_INFO_OPTIONS_LABEL.map(val => ({
      label: `NETWORK.${val}`
    }))
  }

  setLocationOptions = () => {
    this.locationOptions = LOCATION_LABEL.map(val => ({
      label: `LOCATION.${val}`,
      value: ''
    }))
  }

  changeCountry = () => {
    let cityOptions = this.locationService.getCities();
    cityOptions = cityOptions.filter(c => c.countryId === this.country);
    this.cityOptions = cityOptions;
  }

  changeCity = () => {
    let districtOptions = this.locationService.getDistricts();
    districtOptions = districtOptions.filter(c => c.cityId === this.city);
    this.districtOptions = districtOptions;
  }

  save = () => {
    console.log('save');
  }
}
