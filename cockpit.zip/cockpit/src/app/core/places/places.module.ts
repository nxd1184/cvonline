import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { PlacesRoutes } from './places.routing';
import { TranslateModule } from '@ngx-translate/core';
import { PlacesComponent } from './places/places.component';
import { PlacesToolbarComponent } from './places-toolbar/places-toolbar.component';
import { ContactInfoComponent } from './contact-info/contact-info.component';
import { FacilitiesOthersComponent } from './facilities-others/facilities-others.component';
import { ThemesEditorComponent } from './themes-editor/themes-editor.component';
import { FormsModule, ReactiveFormsModule, FormControl } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { ContractComponent } from './contract/contract.component';
import { CompleteComponent } from './complete/complete.component';
import { GeneralInfoComponent } from './general-info/general-info.component';
import { PlacesResultsComponent } from './places-results/places-results.component';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CoreProviderService } from '../../services/core-provider.service';

import { AgmCoreModule } from '@agm/core';
import { MenuComponent } from './menu/menu.component';
import { DragulaModule } from 'ng2-dragula/ng2-dragula';
import { PhotoMenuComponent } from './photo-menu/photo-menu.component';
import { PhotosComponent } from './photos/photos.component';
import { DishListComponent } from './dish-list/dish-list.component';

import { FileUploadModule } from 'ng2-file-upload/ng2-file-upload';
import {PlaceService} from '../../services/place.service';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(PlacesRoutes),
    TranslateModule,
    NgxDatatableModule,
    FormsModule,
    NgSelectModule,
    NgbModule,
    DragulaModule,
    FileUploadModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyBUgFRE0eFZXJLGpf3QCNIg7O4m9RI8S88',
      libraries: ['places']
    }),
    ReactiveFormsModule
  ],
  declarations: [
    PlacesComponent,
    PlacesToolbarComponent,
    ContactInfoComponent,
    FacilitiesOthersComponent,
    ThemesEditorComponent,
    ContractComponent,
    CompleteComponent,
    GeneralInfoComponent,
    PlacesResultsComponent,
    MenuComponent,
    PhotoMenuComponent,
    PhotosComponent,
    DishListComponent
  ],
  providers: [CoreProviderService, PlaceService]
})
export class PlacesModule { }
