import { Routes } from '@angular/router';

import { PlacesComponent } from './places/places.component';
import { ContactInfoComponent } from './contact-info/contact-info.component';
import { FacilitiesOthersComponent } from './facilities-others/facilities-others.component';
import { CompleteComponent } from './complete/complete.component';
import { ContractComponent } from './contract/contract.component';
import { GeneralInfoComponent } from './general-info/general-info.component';
import { PlacesResultsComponent } from './places-results/places-results.component';
import { MenuComponent } from './menu/menu.component';
import { PhotosComponent } from './photos/photos.component';
import { PhotoMenuComponent } from './photo-menu/photo-menu.component';
import { DishListComponent } from './dish-list/dish-list.component';

export const PlacesRoutes: Routes = [
  {
    path: '',
    component: PlacesComponent,
    children: [
      {
        path: '',
        component: PlacesResultsComponent
      },
      {
        path: 'contactinfo',
        component: ContactInfoComponent
      },
      {
        path: 'facilitiesandothers',
        component: FacilitiesOthersComponent
      },
      {
        path: 'photos',
        component: PhotosComponent
      },
      {
        path: 'generalinfo',
        component: GeneralInfoComponent
      },
      {
        path: 'legal',
        component: ContractComponent
      },
      {
        path: 'complete',
        component: CompleteComponent
      },
      {
        path: 'dishes',
        children: [
          {
            path: 'dishes',
            component: DishListComponent
          },
          {
            path: 'menu',
            component: MenuComponent
          },
          {
            path: 'menuphotos',
            component: PhotoMenuComponent
          }
        ]
      }
    ]
  }
];
