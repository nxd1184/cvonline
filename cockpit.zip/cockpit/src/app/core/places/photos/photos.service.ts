import { Injectable } from '@angular/core';

export interface Photo {
  id: string;
  url: string;
}

const PHOTOS: Photo[] = [
  {
    id : "1",
    url : "assets/images/test.png"
  },
  {
    id : "2",
    url : "assets/images/test2.png"
  },
  {
    id : "3",
    url : "assets/images/test.png"
  },
  {
    id : "4",
    url : "assets/images/test2.png"
  },
  {
    id : "5",
    url : "assets/images/test.png"
  },
  {
    id : "6",
    url : "assets/images/test2.png"
  },
  {
    id : "7",
    url : "assets/images/test.png"
  },
  {
    id : "8",
    url : "assets/images/test2.png"
  },
  {
    id : "9",
    url : "assets/images/test2.png"
  }
];


@Injectable()
export class PhotoService {
  getPhotos(): Photo[] {
    return PHOTOS;
  }
}
