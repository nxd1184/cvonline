import { Component, OnInit } from '@angular/core';
import { PhotoService } from './photos.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-photos',
  templateUrl: './photos.component.html',
  styleUrls: ['./photos.component.scss'],
  providers: [PhotoService]
})
export class PhotosComponent implements OnInit {

  photos = [];

  constructor(
    public translate: TranslateService,
    public photoService: PhotoService
  ) { }

  ngOnInit() {
    this.photos = this.photoService.getPhotos();
  }

  delete = (photo_index) => {
    this.photos.splice(photo_index,1);
  }

  upload = (ev) => {
    if(ev.target.files && ev.target.files[0].type.indexOf("image") !== -1){
      this.photos.push({
        id : `${this.photos.length}`,
        url : "assets/images/test.png"
      })
    }
  }

  save = () => {
    console.log('save');
  }
}
