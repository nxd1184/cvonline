import { Component, OnInit } from '@angular/core';
import { PhotoService } from '../photos/photos.service';

@Component({
  selector: 'app-photo-menu',
  templateUrl: './photo-menu.component.html',
  styleUrls: ['./photo-menu.component.scss'],
  providers: [PhotoService]
})
export class PhotoMenuComponent implements OnInit {
  photos = [];
  constructor(private photoService: PhotoService) { }

  ngOnInit() {
    this.photos = this.photoService.getPhotos();
  }

  delete = (photo_index) => {
    this.photos.splice(photo_index, 1);
  }

  upload = (ev) => {
    if (ev.target.files && ev.target.files[0].type.indexOf('image') !== -1){
      this.photos.push({
        id : `${this.photos.length}`,
        url : 'assets/images/test.png'
      });
    }
  }

  save = () => {
    console.log('save');
  }

}
