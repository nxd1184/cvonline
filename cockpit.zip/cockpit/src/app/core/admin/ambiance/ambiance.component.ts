import { Component, OnInit, ViewChild, TemplateRef } from "@angular/core";
import { CoreProviderService } from "../../../services/core-provider.service";
import { SearchOption } from "../../../models/SearchOption";
import {Ambiance, CoreProvider} from '../../../models/core-provider.model';
import { NgbModal, NgbModalRef } from "@ng-bootstrap/ng-bootstrap";
import { FormBuilder, FormGroup, FormArray } from "@angular/forms";
import {I18n} from '../../../components/datepicker/datepicker.component';

@Component({
  selector: "app-ambiance",
  templateUrl: "./ambiance.component.html",
  styleUrls: ["./ambiance.component.scss"]
})
export class AmbianceComponent implements OnInit {
  @ViewChild("recycleBinTemplate") recycleBinTemplate: TemplateRef<any>;
  @ViewChild("pencilTemplate") pencilTemplate: TemplateRef<any>;

  @ViewChild("editAmbianceModal") editAmbianceModal;

  page = {
    pageNumber: 0,
    totalElements: 0,
    size: 10,
    offset: 0
  };

  ambiances = [];

  columns: any;

  editForm: FormGroup;
  action: string;
  edit_id: "";
  modalRef: NgbModalRef;

  langs = [
    { name: "French", img: "fr" },
    { name: "Dutch", img: "de" },
    { name: "Vietnamese", img: "vi" }
  ];

  langOrigin = { name: "English", img: "en" };

  constructor(
    private modalService: NgbModal,
    private fb: FormBuilder,
    private coreProviderService: CoreProviderService
  ) {}

  ngOnInit() {
    this.columns = [
      { name: "AmbianceId", prop: "id" },
      { name: "en_us", prop: "en" },
      { name: "vi_vn", prop: "vi" },
      { name: "fr_fr", prop: "fr" },
      { name: "de_de", prop: "de" },
      { name: "", prop: "recycle_bin", cellTemplate: this.recycleBinTemplate },
      { name: "", prop: "pencil", cellTemplate: this.pencilTemplate }
    ];
    this.getAmbiances({ offset: 0 });
  }

  createAmbianceForm(nameOrigin = this.createAmbianceOrigin()) {
    this.editForm = this.fb.group({
      nameOrigin,
      nameLocals: this.fb.array([])
    });
  }

  delete_lang(index) {
    this.nameLocals.removeAt(index);
  }

  get nameLocals() {
    return this.editForm.get("nameLocals") as FormArray;
  }

  createAmbianceOrigin(name = "") {
    return this.fb.group({ name });
  }

  createAmbianceLocal(flag = this.langs[0], name = "") {
    return this.fb.group({ flag, name });
  }

  cloneDivLanguage() {
    this.nameLocals.push(this.createAmbianceLocal());
  }

  onSubmit() {
    const { nameOrigin, nameLocals } = this.editForm.value;
    const ambiance: Ambiance = new Ambiance().default();
    ambiance.name.texts.push({
      display_text: nameOrigin.name,
      locale_id: 'en'
    });

    nameLocals.forEach(n => {
      ambiance.name.texts.push({
        display_text: n.name,
        locale_id: n.flag.img
      });
    });

    if (this.action === "create") {
      this.create(ambiance);
    } else if (this.action === "edit") {
      ambiance.id = Number(this.edit_id);
      this.edit(ambiance);
    }
  }

  getAmbiances(pageInfo) {
    const options = new SearchOption();
    options.limit = this.page.size;
    options.offset = pageInfo.offset * this.page.size;
    this.page.offset = pageInfo.offset;

    this.coreProviderService.getAmbiances(options).subscribe(data => {
      this.page.totalElements = data[0];
      this.ambiances = data[1];

      this.ambiances = data[1].map(a => {
        const item = {
          id: a.id,
        };
        a.name.texts.forEach(l => {
          item[l.locale_id] = l.display_text;
        });
        return item;
      });
    });
  }

  handleCreate = () => {
    this.action = "create";
    this.createAmbianceForm();
    this.cloneDivLanguage();
    this.modalRef = this.modalService.open(this.editAmbianceModal, {
      centered: true,
      size: "lg"
    });
  };

  handleEdit = (ev, row) => {
    //fix error: conflit datatable && modal
    ev.target.parentElement.parentElement.parentElement.blur();

    this.action = "edit";
    const ambiance = this.ambiances.find(a => a.id === row.id);
    this.edit_id = ambiance.id;
    const nameOrigin = this.createAmbianceOrigin(ambiance.en);
    this.createAmbianceForm(nameOrigin);
    Object.keys(ambiance)
      .filter(key => key !== "id" && key !== this.langs[0].img)
      .forEach(key => {
        this.nameLocals.push(
          this.createAmbianceLocal(
            this.langs.find(la => la.img === key),
            ambiance[key]
          )
        );
      });

    this.modalRef = this.modalService.open(this.editAmbianceModal, {
      centered: true,
      size: "lg"
    });
  };

  create = val => {
    this.coreProviderService.createAmbiance(val).subscribe(res => {
      if (res) {
        this.modalRef.close();
        this.reload();
      }
    });
  };

  edit = val => {
    this.coreProviderService.updateAmbiance(val).subscribe(res => {
      if (res) {
        this.modalRef.close();
        this.reload();
      }
    });
  };

  delete(row) {
    this.coreProviderService.deleteAmbiance(row.id).subscribe(res => {
      if (res) {
        this.reload();
      }
    });
  }

  reload = () => {
    const { offset } = this.page;
    this.getAmbiances({ offset });
  };

  getRowClass(row) {
    return "datatable-row";
  }
}
