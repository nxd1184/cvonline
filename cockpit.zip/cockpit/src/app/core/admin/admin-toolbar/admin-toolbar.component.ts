import { Component, Input } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { UTILITIES } from '../admin/utilities';

@Component({
  selector: 'app-admin-toolbar',
  templateUrl: './admin-toolbar.component.html',
  styleUrls: ['./admin-toolbar.component.scss']
})
export class AdminToolbarComponent {
  @Input() nameComponent: string;
  utilities = UTILITIES;
  constructor(public translate: TranslateService) { }
}
