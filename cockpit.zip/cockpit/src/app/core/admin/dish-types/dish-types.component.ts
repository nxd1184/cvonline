import { Component, OnInit, ViewChild, TemplateRef } from "@angular/core";
import { CoreProviderService } from "../../../services/core-provider.service";
import { SearchOption } from "../../../models/SearchOption";
import { CoreProvider } from "../../../models/core-provider.model";
import {
  FormGroup,
  FormControl,
  Validators,
  FormArray,
  FormBuilder
} from "../../../../../node_modules/@angular/forms";
import {
  NgbModal,
  NgbModalRef
} from "../../../../../node_modules/@ng-bootstrap/ng-bootstrap";

@Component({
  selector: "app-dish-types",
  templateUrl: "./dish-types.component.html",
  styleUrls: ["./dish-types.component.scss"]
})
export class DishTypesComponent implements OnInit {
  @ViewChild("recycleBinTemplate") recycleBinTemplate: TemplateRef<any>;
  @ViewChild("pencilTemplate") pencilTemplate: TemplateRef<any>;
  @ViewChild("editDishTypeModal") editDishTypeModal;

  page = {
    pageNumber: 0,
    totalElements: 0,
    size: 10,
    offset: 0
  };

  dishTypes = [];

  columns: any;

  editForm: FormGroup;
  action: string;
  edit_id: "";
  modalRef: NgbModalRef;

  langs = [
    { name: "French", img: "fr" },
    { name: "Dutch", img: "de" },
    { name: "Vietnamese", img: "vi" }
  ];

  langOrigin = { name: "English", img: "en" };

  constructor(
    private modalService: NgbModal,
    private fb: FormBuilder,
    private coreProviderService: CoreProviderService
  ) {}

  ngOnInit() {
    this.columns = [
      { name: "DTypeId", prop: "id" },
      { name: "en_us", prop: "en" },
      { name: "vi_vn", prop: "vi" },
      { name: "fr_fr", prop: "fr" },
      { name: "de_de", prop: "de" },
      { name: "", prop: "recycle_bin", cellTemplate: this.recycleBinTemplate },
      { name: "", prop: "pencil", cellTemplate: this.pencilTemplate }
    ];
    this.getDishTypes({ offset: 0 });
  }

  createDishTypeForm(nameOrigin = this.createDishTypeOrigin()) {
    this.editForm = this.fb.group({
      nameOrigin,
      nameLocals: this.fb.array([])
    });
  }

  delete_lang(index) {
    this.nameLocals.removeAt(index);
  }

  get nameLocals() {
    return this.editForm.get("nameLocals") as FormArray;
  }

  createDishTypeOrigin(name = "") {
    return this.fb.group({ name });
  }

  createDishTypeLocal(flag = this.langs[0], name = "") {
    return this.fb.group({ flag, name });
  }

  cloneDivLanguage() {
    this.nameLocals.push(this.createDishTypeLocal());
  }

  onSubmit() {
    const { nameOrigin, nameLocals } = this.editForm.value;
    let newO = {
      en: "",
      fr: "",
      vi: "",
      de: ""
    };
    newO.en = nameOrigin.name;
    nameLocals.forEach(n => {
      newO[n.flag.img] = n.name;
    });

    if (this.action === "create") {
      this.create({ languages: newO });
    } else if (this.action === "edit") {
      this.edit({
        id: this.edit_id,
        languages: newO
      });
    }
  }

  getDishTypes(pageInfo) {
    const options = new SearchOption();
    options.limit = this.page.size;
    options.offset = pageInfo.offset * this.page.size;
    this.page.offset = options.offset;
    this.coreProviderService.getDishTypes(options).subscribe(data => {
      this.page.totalElements = data[0];

      this.dishTypes = data[1].map(a => ({
        id: a.id,
        en: a.name,
        fr: a.languages.fr,
        de: a.languages.de,
        vi: a.languages.vi
      }));
    });
  }

  handleCreate = () => {
    this.action = "create";
    this.createDishTypeForm();
    this.cloneDivLanguage();
    this.modalRef = this.modalService.open(this.editDishTypeModal, {
      centered: true,
      size: "lg"
    });
  };

  handleEdit = (ev, row) => {
    //fix error: conflit datatable && modal
    ev.target.parentElement.parentElement.parentElement.blur();

    this.action = "edit";
    const dishType = this.dishTypes.find(a => a.id === row.id);
    this.edit_id = dishType.id;
    const nameOrigin = this.createDishTypeOrigin(dishType.en);
    this.createDishTypeForm(nameOrigin);
    Object.keys(dishType)
      .filter(key => key !== "id" && key !== this.langs[0].img)
      .forEach(key => {
        this.nameLocals.push(
          this.createDishTypeLocal(
            this.langs.find(la => la.img === key),
            dishType[key]
          )
        );
      });

    this.modalRef = this.modalService.open(this.editDishTypeModal, {
      centered: true,
      size: "lg"
    });
  };

  create = val => {
    this.coreProviderService.createDishType(val).subscribe(res => {
      if (res) {
        this.modalRef.close();
        this.reload();
      }
    });
  };

  edit = val => {
    this.coreProviderService.updateDishType(val).subscribe(res => {
      if (res) {
        this.modalRef.close();
        this.reload();
      }
    });
  };

  delete(row) {
    this.coreProviderService.deleteDishType(row.id).subscribe(res => {
      if (res) {
        this.reload();
      }
    });
  }

  reload = () => {
    const { offset } = this.page;
    this.getDishTypes({ offset });
  };

  getRowClass(row) {
    return "datatable-row";
  }
}
