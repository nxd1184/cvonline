import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { CoreProviderService } from '../../../services/core-provider.service';
import { FormGroup, FormBuilder, FormControl, Validators, FormArray } from '../../../../../node_modules/@angular/forms';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { Cuisine } from '../../../models/core-provider.model';
import { SearchOption } from '../../../models/SearchOption';

@Component({
  selector: 'app-cuisines',
  templateUrl: './cuisines.component.html',
  styleUrls: ['./cuisines.component.scss']
})
export class CuisinesComponent implements OnInit {
  @ViewChild('recycleBinTemplate') recycleBinTemplate: TemplateRef<any>;
  @ViewChild('pencilTemplate') pencilTemplate: TemplateRef<any>;
  @ViewChild('cuisineModal') cuisineModalTemplate;
  page = {
    pageNumber: 0,
    totalElements: 0,
    size: 10
  };
  cuisines = [];
  columns: any;
  nameComponent: string;
  cuisineForm: FormGroup;
  cuisineModal: NgbModalRef;
  langs = [
    { id: 'fr', name: 'French', img: 'fr' },
    { id: 'de', name: 'Dutch', img: 'de' },
    { id: 'vi', name: 'Vietnamese', img: 'vi' }
  ];
  isEditForm = false;
  cuisineIdSelected = 0;
  cuisineParents: any[];
  constructor(
    private modalService: NgbModal,
    private fb: FormBuilder,
    private coreProviderService: CoreProviderService) { }

  ngOnInit() {
    this.columns = [
      { name: 'CuisineId', prop: 'id', width: 100 },
      { name: 'Name', prop: 'name' },
      { name: 'Parent', prop: 'parents' },
      { name: 'Children', prop: 'children' },
      { name: 'vi', prop: 'languages.vi' },
      { name: 'en', prop: 'languages.en' },
      { name: 'fr', prop: 'languages.fr' },
      { name: 'de', prop: 'languages.de' },
      { name: '', prop: 'pencil', cellTemplate: this.pencilTemplate, width: 50 },
      { name: '', prop: 'recycle_bin', cellTemplate: this.recycleBinTemplate, width: 50 }
    ];
    this.getCuisines({ offset: 0 });
    this.getListCuisineName();
    this.createCuisineForm();
  }

  createCuisineForm() {
    this.cuisineForm = this.fb.group({
      nameOrigin: [{ value: '' }, Validators.required],
      parents: [],
      nameLocals: this.fb.array([this.createCuisineLocal()])
    });
  }

  get nameLocals() {
    return this.cuisineForm.get('nameLocals') as FormArray;
  }

  createCuisineLocal() {
    return this.fb.group({
      flag: this.langs[0],
      name: ''
    });
  }

  resetForm() {
    this.cuisineForm.reset({
      nameOrigin: '',
    });
    this.cuisineForm.setControl('nameLocals', this.fb.array([this.createCuisineLocal()]));
  }

  addCuisineLocal() {
    this.nameLocals.push(this.createCuisineLocal());
  }

  deleteCuisineLocal(index) {
    this.nameLocals.removeAt(index);
  }

  getCuisines(pageInfo) {
    const options = new SearchOption();
    options.limit = this.page.size;
    options.offset = pageInfo.offset * this.page.size;
    this.page.pageNumber = pageInfo.offset;
    this.coreProviderService.getCuisines(options).subscribe(pagedData => {
      this.cuisines = pagedData[1];
      this.page.totalElements = pagedData[0];
    });
  }

  // Get List Cuisine's Name - Will be replace by API
  getListCuisineName() {
    const options = new SearchOption();
    options.limit = this.page.size;
    options.offset = 0;
    this.coreProviderService.getCuisines(options).subscribe(pagedData => {
      this.cuisineParents = pagedData[1].map(cuisine => {
        return {
          name: cuisine.name,
          id: cuisine.id
        };
      });
    });
  }

  openModal() {
    this.cuisineModal = this.modalService.open(this.cuisineModalTemplate, { centered: true, size: 'lg' });
    this.isEditForm = false;
    this.resetForm();
  }

  onSubmit() {
    const formModel = this.cuisineForm.value;
    const cuisineToSubmit = this.getCuisineModel(formModel);
    this.isEditForm ? this.updateCuisine(cuisineToSubmit) : this.createCuisine(cuisineToSubmit);
  }

  createCuisine(cuisineToSubmit) {
    this.coreProviderService.createCuisine(cuisineToSubmit)
      .subscribe(res => {
        alert(res ? 'Successful' : 'Failed');
        this.doAfterSubmit();
      });
  }

  updateCuisine(cuisineToSubmit) {
    this.coreProviderService.updateCuisine(cuisineToSubmit).subscribe(res => {
      alert(res ? 'Successful' : 'Failed');
      this.doAfterSubmit();
    });
  }

  doAfterSubmit() {
    this.cuisineModal.close();
    this.reload();
  }

  reload() {
    this.getCuisines({ offset: this.page.pageNumber });
  }

  getCuisineModel(formModel) {
    const cuisine = new Cuisine();
    if (this.isEditForm) {
      cuisine.id = this.cuisineIdSelected;
    }
    const nameOrigin = formModel.nameOrigin;
    const nameLocals = formModel.nameLocals;
    const languages = {};
    languages['en'] = nameOrigin;
    nameLocals.forEach(nameLocal => {
      languages[nameLocal.flag.img] = nameLocal.name;
    });
    cuisine.parents = formModel.parents;
    cuisine.languages = languages;
    return cuisine;
  }

  editCuisine(ev, row) {
    ev.target.parentElement.parentElement.parentElement.blur();
    this.openModal();
    this.cuisineIdSelected = row.id;
    this.isEditForm = true;
    const languages = row.languages;
    const nameLocals = [];
    Object.keys(languages).forEach(function (key, index) {
      if (key !== 'en') {
        nameLocals.push({
          flag: this.langs.find(lang => lang.id === key),
          name: languages[key]
        });
      }
    }.bind(this));

    this.cuisineForm.patchValue({
      nameOrigin: row.languages.en,
      parents: row.parents
    });
    this.cuisineForm.setControl('nameLocals', this.fb.array(nameLocals.map(i => this.fb.group(i))));
  }

  delete(row) {
    this.coreProviderService.deleteCuisine(row.id).subscribe(res => {
      alert(res ? 'Successful' : 'Failed');
      this.reload();
    });
  }

  getRowClass(row) {
    return 'datatable-row';
  }
}
