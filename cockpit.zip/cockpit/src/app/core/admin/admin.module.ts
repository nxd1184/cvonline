import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { NgSelectModule } from "@ng-select/ng-select";

import { AdminComponent } from "./admin/admin.component";

import { CuisinesComponent } from "./cuisines/cuisines.component";
import { IngredientsComponent } from "./ingredients/ingredients.component";
import { RestaurantTypesComponent } from "./restaurant-types/restaurant-types.component";
import { SpecialtiesComponent } from "./specialties/specialties.component";

import { AdminToolbarComponent } from "./admin-toolbar/admin-toolbar.component";
import { RouterModule } from "@angular/router";
import { AdminRoutes } from "./admin.routing";
import { TranslateModule } from "@ngx-translate/core";
import { NgxDatatableModule } from "@swimlane/ngx-datatable";
import { DashboardAdminComponent } from "./dashboard-admin/dashboard-admin.component";
import { CoreProviderService } from "../../services/core-provider.service";
import { AmbianceComponent } from "./ambiance/ambiance.component";
import { CookingMethodComponent } from "./cooking-method/cooking-method.component";
import { DishTypesComponent } from "./dish-types/dish-types.component";
import { FacilitiesComponent } from "./facilities/facilities.component";
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(AdminRoutes),
    TranslateModule,
    ReactiveFormsModule,
    FormsModule,
    NgxDatatableModule,
    NgSelectModule
  ],
  declarations: [
    AdminComponent,
    AdminToolbarComponent,
    CuisinesComponent,
    IngredientsComponent,
    RestaurantTypesComponent,
    SpecialtiesComponent,
    DashboardAdminComponent,
    AmbianceComponent,
    CookingMethodComponent,
    DishTypesComponent,
    FacilitiesComponent
  ],
  providers: [CoreProviderService]
})
export class AdminModule {}
