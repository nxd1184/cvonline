import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { CoreProviderService } from '../../../services/core-provider.service';
import { SearchOption } from '../../../models/SearchOption';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { Ingredient } from '../../../models/core-provider.model';

@Component({
  selector: 'app-ingredients',
  templateUrl: './ingredients.component.html',
  styleUrls: ['./ingredients.component.scss']
})
export class IngredientsComponent implements OnInit {
  @ViewChild('recycleBinTemplate') recycleBinTemplate: TemplateRef<any>;
  @ViewChild('pencilTemplate') pencilTemplate: TemplateRef<any>;
  @ViewChild('ingredientModal') ingredientModalTemplate;
  page = {
    pageNumber: 0,
    totalElements: 0,
    size: 10
  };
  ingredients = [];
  columns: any;
  nameComponent: string;
  langs = [
    { id: 'fr', name: 'French', img: 'fr' },
    { id: 'de', name: 'Dutch', img: 'de' },
    { id: 'vi', name: 'Vietnamese', img: 'vi' }
  ];
  isEditForm = false;
  ingredientIdSelected = 0;
  ingredientParents: any[];
  ingredientForm: FormGroup;
  ingredientModal: NgbModalRef;

  constructor(
    private modalService: NgbModal,
    private fb: FormBuilder,
    private coreProviderService: CoreProviderService) { }

  ngOnInit() {
    this.columns = [
      { name: 'IngredientId', prop: 'id' },
      { name: 'Name', prop: 'name' },
      { name: 'Parent', prop: 'parents' },
      { name: 'Children', prop: 'children' },
      { name: 'vi', prop: 'languages.vi' },
      { name: 'en', prop: 'languages.en' },
      { name: 'fr', prop: 'languages.fr' },
      { name: 'de', prop: 'languages.de' },
      { name: '', prop: 'pencil', cellTemplate: this.pencilTemplate, width: 50 },
      { name: '', prop: 'recycle_bin', cellTemplate: this.recycleBinTemplate }
    ];
    this.nameComponent = 'ADMIN.INGREDIENTS';
    this.getIngredients({ offset: 0 });
    this.getListIngredientName();
    this.createIngredientForm();
  }

  createIngredientForm() {
    this.ingredientForm = this.fb.group({
      nameOrigin: [{ value: '' }, Validators.required],
      parents: [],
      nameLocals: this.fb.array([this.createIngredientLocal()])
    });
  }

  get nameLocals() {
    return this.ingredientForm.get('nameLocals') as FormArray;
  }

  createIngredientLocal() {
    return this.fb.group({
      flag: this.langs[0],
      name: ''
    });
  }

  resetForm() {
    this.ingredientForm.reset({
      nameOrigin: ''
    });
    this.ingredientForm.setControl('nameLocals', this.fb.array([this.createIngredientLocal()]));
  }

  addIngredientLocal() {
    this.nameLocals.push(this.createIngredientLocal());
  }

  deleteIngredientLocal(index) {
    this.nameLocals.removeAt(index);
  }

  openModal() {
    this.ingredientModal = this.modalService.open(this.ingredientModalTemplate, { centered: true, size: 'lg' });
    this.isEditForm = false;
    this.resetForm();
  }

  onSubmit() {
    const formModel = this.ingredientForm.value;
    const ingredientToSubmit = this.getIngredientModel(formModel);
    this.isEditForm ? this.updateIngredient(ingredientToSubmit) : this.createIngredient(ingredientToSubmit);
  }

  createIngredient(ingredientToSubmit) {
    this.coreProviderService.createIngredient(ingredientToSubmit)
      .subscribe(res => {
        alert(res ? 'Successful' : 'Failed');
        this.doAfterSubmit();
      });
  }

  updateIngredient(ingredientToSubmit) {
    this.coreProviderService.updateIngredient(ingredientToSubmit).subscribe(res => {
      alert(res ? 'Successful' : 'Failed');
      this.doAfterSubmit();
    });
  }

  doAfterSubmit() {
    this.ingredientModal.close();
    this.reload();
  }

  reload() {
    this.getIngredients({ offset: this.page.pageNumber });
  }


  getIngredientModel(formModel) {
    const ingredient = new Ingredient();
    if (this.isEditForm) {
      ingredient.id = this.ingredientIdSelected;
    }
    const nameOrigin = formModel.nameOrigin;
    const nameLocals = formModel.nameLocals;
    const languages = {};
    languages['en'] = nameOrigin;
    nameLocals.forEach(nameLocal => {
      languages[nameLocal.flag.img] = nameLocal.name;
    });
    ingredient.parents = formModel.parents;
    ingredient.languages = languages;
    return ingredient;
  }

  getIngredients(pageInfo) {
    const options = new SearchOption();
    options.limit = this.page.size;
    options.offset = pageInfo.offset * this.page.size;
    this.coreProviderService.getIngredients(options).subscribe(pagedData => {
      this.ingredients = pagedData[1];
      this.page.totalElements = pagedData[0];
    });
  }

  // Get List Ingredient's Name - Will be replace by API
  getListIngredientName() {
    const options = new SearchOption();
    options.limit = this.page.size;
    options.offset = 0;
    this.coreProviderService.getIngredients(options).subscribe(pagedData => {
      this.ingredientParents = pagedData[1].map(ingredient => {
        return {
          name: ingredient.name,
          id: ingredient.id
        };
      });
    });
  }

  editIngredient(ev, row) {
    ev.target.parentElement.parentElement.parentElement.blur();
    this.openModal();
    this.isEditForm = true;
    this.ingredientIdSelected = row.id;
    const languages = row.languages;
    const nameLocals = [];
    Object.keys(languages).forEach(function (key, index) {
      if (key !== 'en') {
        nameLocals.push({
          flag: this.langs.find(lang => lang.id === key),
          name: languages[key]
        });
      }
    }.bind(this));

    this.ingredientForm.patchValue({
      nameOrigin: row.languages.en,
      parents: row.parents
    });
    this.ingredientForm.setControl('nameLocals', this.fb.array(nameLocals.map(i => this.fb.group(i))));
  }

  delete(row) {
    this.coreProviderService.deleteIngredient(row.id).subscribe(res => {
      alert(res);
      this.reload();
    });
  }

  getRowClass(row) {
    return 'datatable-row';
  }
}
