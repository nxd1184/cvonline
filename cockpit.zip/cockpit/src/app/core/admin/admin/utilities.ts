export const UTILITIES = [
  {
    key: 'CUISINES',
    text: 'ADMIN.CUISINES',
    icon: 'test.png',
    route: 'cuisines'
  },
  {
    key: 'INGREDIENTS',
    text: 'ADMIN.INGREDIENTS',
    icon: 'test.png',
    route: 'ingredients'
  },
  {
    key: 'RESTAURANT_TYPE',
    text: 'ADMIN.RESTAURANT_TYPE',
    icon: 'test.png',
    route: 'restaurant_type'
  },
  {
    key: 'SPECIALTY',
    text: 'ADMIN.SPECIALTY',
    icon: 'test.png',
    route: 'specialty'
  },
  {
    key: 'AMBIANCE',
    text: 'ADMIN.AMBIANCE',
    icon: 'test.png',
    route: 'ambiance'
  },
  {
    key: 'DISH_TYPE',
    text: 'ADMIN.DISH_TYPE',
    icon: 'test.png',
    route: 'dish_type'
  },
  {
    key: 'FACILITIES',
    text: 'ADMIN.FACILITIES',
    icon: 'test.png',
    route: 'facilities'
  },
  {
    key: 'COOKING_METHOD',
    text: 'ADMIN.COOKING_METHOD',
    icon: 'test.png',
    route: 'cooking_method'
  }
];
