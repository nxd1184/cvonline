import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent {
  hasAdminToolbar: boolean;

  constructor(public translate: TranslateService, private router: Router) {
    this.router.events.subscribe((events) => {
      if (events instanceof NavigationEnd) {
        if (events.url === '/admin') {
          this.hasAdminToolbar = false;
        } else {
          this.hasAdminToolbar = true;
        }
      }
    });
  }
}
