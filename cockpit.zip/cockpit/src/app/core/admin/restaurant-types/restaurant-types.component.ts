import { Component, OnInit, ViewChild, TemplateRef } from "@angular/core";
import { CoreProviderService } from "../../../services/core-provider.service";
import { SearchOption } from "../../../models/SearchOption";
import { CoreProvider } from "../../../models/core-provider.model";
import {
  FormGroup,
  FormBuilder,
  FormArray
} from "../../../../../node_modules/@angular/forms";
import {
  NgbModal,
  NgbModalRef
} from "../../../../../node_modules/@ng-bootstrap/ng-bootstrap";

@Component({
  selector: "app-restaurant-types",
  templateUrl: "./restaurant-types.component.html",
  styleUrls: ["./restaurant-types.component.scss"]
})
export class RestaurantTypesComponent implements OnInit {
  @ViewChild("recycleBinTemplate") recycleBinTemplate: TemplateRef<any>;
  @ViewChild("pencilTemplate") pencilTemplate: TemplateRef<any>;
  @ViewChild("editRestaurantTypeModal") editRestaurantTypeModal;

  page = {
    pageNumber: 0,
    totalElements: 0,
    size: 10,
    offset: 0
  };

  restaurantTypes = [];
  columns: any;

  editForm: FormGroup;
  action: string;
  edit_id: "";
  modalRef: NgbModalRef;

  langs = [
    { name: "French", img: "fr" },
    { name: "Dutch", img: "de" },
    { name: "Vietnamese", img: "vi" }
  ];

  langOrigin = { name: "English", img: "en" };
  constructor(
    private modalService: NgbModal,
    private fb: FormBuilder,
    private coreProviderService: CoreProviderService
  ) {}

  ngOnInit() {
    this.columns = [
      { name: "DTypeId", prop: "id" },
      { name: "en_us", prop: "en" },
      { name: "vi_vn", prop: "vi" },
      { name: "fr_fr", prop: "fr" },
      { name: "de_de", prop: "de" },
      { name: "", prop: "recycle_bin", cellTemplate: this.recycleBinTemplate },
      { name: "", prop: "pencil", cellTemplate: this.pencilTemplate }
    ];
    this.getRestaurantTypes({ offset: 0 });
  }

  createRestaurantTypeForm(nameOrigin = this.createRestaurantTypeOrigin()) {
    this.editForm = this.fb.group({
      nameOrigin,
      nameLocals: this.fb.array([])
    });
  }

  delete_lang(index) {
    this.nameLocals.removeAt(index);
  }

  get nameLocals() {
    return this.editForm.get("nameLocals") as FormArray;
  }

  createRestaurantTypeOrigin(name = "") {
    return this.fb.group({ name });
  }

  createRestaurantTypeLocal(flag = this.langs[0], name = "") {
    return this.fb.group({ flag, name });
  }

  cloneDivLanguage() {
    this.nameLocals.push(this.createRestaurantTypeLocal());
  }

  onSubmit() {
    const { nameOrigin, nameLocals } = this.editForm.value;
    let newO = {
      en: "",
      fr: "",
      vi: "",
      de: ""
    };
    newO.en = nameOrigin.name;
    nameLocals.forEach(n => {
      newO[n.flag.img] = n.name;
    });

    if (this.action === "create") {
      this.create({ languages: newO });
    } else if (this.action === "edit") {
      this.edit({
        id: this.edit_id,
        languages: newO
      });
    }
  }

  getRestaurantTypes(pageInfo) {
    const options = new SearchOption();
    options.limit = this.page.size;
    options.offset = pageInfo.offset * this.page.size;
    this.page.offset = pageInfo.offset;
    this.coreProviderService.getRestaurantTypes(options).subscribe(data => {
      this.page.totalElements = data[0];

      this.restaurantTypes = data[1].map(a => ({
        id: a.id,
        en: a.name,
        fr: a.languages.fr,
        de: a.languages.de,
        vi: a.languages.vi
      }));
    });
  }

  handleCreate = () => {
    this.action = "create";
    this.createRestaurantTypeForm();
    this.cloneDivLanguage();
    this.modalRef = this.modalService.open(this.editRestaurantTypeModal, {
      centered: true,
      size: "lg"
    });
  };

  handleEdit = (ev, row) => {
    //fix error: conflit datatable && modal
    ev.target.parentElement.parentElement.parentElement.blur();

    this.action = "edit";
    const restaurantType = this.restaurantTypes.find(a => a.id === row.id);
    this.edit_id = restaurantType.id;
    const nameOrigin = this.createRestaurantTypeOrigin(restaurantType.en);
    this.createRestaurantTypeForm(nameOrigin);
    Object.keys(restaurantType)
      .filter(key => key !== "id" && key !== this.langs[0].img)
      .forEach(key => {
        this.nameLocals.push(
          this.createRestaurantTypeLocal(
            this.langs.find(la => la.img === key),
            restaurantType[key]
          )
        );
      });

    this.modalRef = this.modalService.open(this.editRestaurantTypeModal, {
      centered: true,
      size: "lg"
    });
  };

  create = val => {
    this.coreProviderService.createRestaurantType(val).subscribe(res => {
      if (res) {
        this.modalRef.close();
        this.reload();
      }
    });
  };

  edit = val => {
    this.coreProviderService.updateRestaurantType(val).subscribe(res => {
      if (res) {
        this.modalRef.close();
        this.reload();
      }
    });
  };

  delete(row) {
    this.coreProviderService.deleteRestaurantType(row.id).subscribe(res => {
      if (res) {
        this.reload();
      }
    });
  }

  reload = () => {
    const { offset } = this.page;
    this.getRestaurantTypes({ offset });
  };

  getRowClass(row) {
    return "datatable-row";
  }
}
