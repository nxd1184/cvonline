import { Component, OnInit } from '@angular/core';
import { UTILITIES } from '../admin/utilities';
@Component({
  selector: 'app-dashboard-admin',
  templateUrl: './dashboard-admin.component.html',
  styleUrls: ['./dashboard-admin.component.scss']
})
export class DashboardAdminComponent {
  utilities = UTILITIES;
  constructor() { }
}
