import { Routes } from '@angular/router';

import { AdminComponent } from './admin/admin.component';
import { CuisinesComponent } from './cuisines/cuisines.component';
import { IngredientsComponent } from './ingredients/ingredients.component';
import { RestaurantTypesComponent } from './restaurant-types/restaurant-types.component';
import { SpecialtiesComponent } from './specialties/specialties.component';
import { DashboardAdminComponent } from './dashboard-admin/dashboard-admin.component';
import { DishTypesComponent } from './dish-types/dish-types.component';
import { FacilitiesComponent } from './facilities/facilities.component';
import { CookingMethodComponent } from './cooking-method/cooking-method.component';
import { AmbianceComponent } from './ambiance/ambiance.component';

export const AdminRoutes: Routes = [
  {
    path: '',
    component: AdminComponent,
    children: [
      {
        path: '',
        component: DashboardAdminComponent
      },
      {
        path: 'cuisines',
        component: CuisinesComponent
      },
      {
        path: 'ingredients',
        component: IngredientsComponent,
      },
      {
        path: 'restaurant_type',
        component: RestaurantTypesComponent,
      },
      {
        path: 'specialty',
        component: SpecialtiesComponent,
      },
      {
        path: 'dish_type',
        component: DishTypesComponent,
      },
      {
        path: 'facilities',
        component: FacilitiesComponent,
      },
      {
        path: 'cooking_method',
        component: CookingMethodComponent,
      },
      {
        path: 'ambiance',
        component: AmbianceComponent,
      }
    ]
  }
];
