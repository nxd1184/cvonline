import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { CoreProviderService } from '../../../services/core-provider.service';

@Component({
  selector: 'app-specialties',
  templateUrl: './specialties.component.html',
  styleUrls: ['./specialties.component.scss']
})
export class SpecialtiesComponent implements OnInit {

  @ViewChild('recycleBinTemplate') recycleBinTemplate: TemplateRef<any>;
  offset = 0;
  limit = 10;
  cuisines = [];
  count = 0;
  columns: any;

  constructor(private coreProviderService: CoreProviderService) { }

  ngOnInit() {
    this.columns = [
      { name: 'RtypeId', prop: 'id' },
      { name: 'Parent', prop: 'parent' },
      { name: 'Children', prop: 'children' },
      { name: 'vi_vn', prop: 'vi_vn' },
      { name: 'en_us', prop: 'en_us' },
      { name: 'fr_fr', prop: 'fr_fr' },
      { name: 'de_de', prop: 'de_de' },
      { name: '', prop: 'recycle_bin', cellTemplate: this.recycleBinTemplate }
    ];
    this.getCuisines();
  }

  getCuisines() {
    // this.coreProviderService.getMockCuisines().subscribe(cuisines => {
    //   this.cuisines = cuisines;
    // });
  }

  delete(row) {
    this.cuisines = this.cuisines.filter(cuisine => cuisine !== row);
  }

  getRowClass(row) {
    return 'datatable-row';
  }
}
