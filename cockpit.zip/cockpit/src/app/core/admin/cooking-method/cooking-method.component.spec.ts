import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CookingMethodComponent } from './cooking-method.component';

describe('CookingMethodComponent', () => {
  let component: CookingMethodComponent;
  let fixture: ComponentFixture<CookingMethodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CookingMethodComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CookingMethodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
