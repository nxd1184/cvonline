import { Component, EventEmitter, Output, Input } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ToolbarMenuService } from './toolbar-menu.service';

@Component({
  selector: 'app-toolbar-menu',
  templateUrl: './toolbar-menu.component.html',
  styleUrls: ['./toolbar-menu.component.scss'],
  providers: [ToolbarMenuService]
})
export class ToolbarMenuComponent{

  constructor(
    public toolbarMenuService : ToolbarMenuService,
    public translate: TranslateService
  ) {}

  @Output() toggleTab: EventEmitter<any> = new EventEmitter();
}
