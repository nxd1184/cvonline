import { Injectable } from '@angular/core';

export interface BadgeItem {
  type: string;
  value: string;
}

export interface ChildrenItems {
  state: string;
  name: string;
  type?: string;
}

export interface Menu {
  state: string;
  name: string;
  type: string;
  icon: string;
  badge?: BadgeItem[];
  children?: ChildrenItems[];
}

const MENUITEMS: Menu[] = [
  {
    state: '/',
    name: 'TOOLBAR.DASHBOARD',
    type: 'link',
    icon: 'test.png'
  },
  {
    state: '/',
    name: 'TOOLBAR.NEW_REGISTRATION',
    type: 'link',
    icon: 'test.png'
  },
  {
    state: 'places',
    name: 'TOOLBAR.PLACES',
    type: 'link',
    icon: 'test.png'
  },
  {
    state: '/',
    name: 'TOOLBAR.CHANNEL',
    type: 'link',
    icon: 'test.png'
  },
  {
    state: 'admin',
    name: 'TOOLBAR.ADMIN',
    type: 'link',
    icon: 'test.png'
  }
];

@Injectable()
export class ToolbarMenuService {
  getAll(): Menu[] {
    return MENUITEMS;
  }
}
