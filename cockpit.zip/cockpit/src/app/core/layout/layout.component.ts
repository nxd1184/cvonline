import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Router, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';

@Component({
    selector: 'app-cockpit-layout',
    templateUrl: 'layout.component.html',
    styleUrls: ['layout.component.scss']
})
export class LayoutComponent implements OnInit{
    options = {
        lang: 'en',
        theme: 'light',
        settings: false,
        docked: false,
        boxed: false,
        opened: true,
        mode: 'push'
    };
    _mode = this.options.mode;
    _autoCollapseWidth = 991;

    private routerEvent: Subscription = null;
    constructor(private translate: TranslateService, private router: Router) {
        this.modifyUrl(router.url);
    }

    modifyUrl = (url) => {
        const path = url.split('/');
        const routes = ['admin', 'places'];
        if (routes.indexOf(path[1]) !== -1 && path.length > 2) {
            this.options.mode = 'dock';
            this._mode = 'dock';
            this._autoCollapseWidth = 0;
        } else {
            this.options.mode = 'push';
            this._mode = 'push';
            this._autoCollapseWidth = 991;
        }
    }

    ngOnInit() {
        this.routerEvent = this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                const navigation = event as NavigationEnd;
                const {url} = navigation;
                this.modifyUrl(url);
            }
        });
    }
    toggleToolbar(): void {
        this.options.opened = !this.options.opened;
    }
}
