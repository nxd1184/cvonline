import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent{
  @Output() toggleSidebar = new EventEmitter<void>();
  languages = ['en', 'fr', 'de', 'vi'];
  language: string;
  constructor(private translate: TranslateService) {
    translate.addLangs(this.languages);
    translate.setDefaultLang('en');

    const browserLang: string = translate.getBrowserLang();
    this.language = browserLang.match(/en|fr|de|vi/) ? browserLang : 'en';
    translate.use(this.language);
  }

  setLang(language) {
    this.language = language;
    this.translate.use(this.language);
  }
}
