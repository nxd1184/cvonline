import { Component } from '@angular/core';

@Component({
  selector: 'app-button-icons',
  templateUrl: './button-icons.component.html',
  styleUrls: ['./button-icons.component.scss']
})
export class ButtonIconsComponent {}
