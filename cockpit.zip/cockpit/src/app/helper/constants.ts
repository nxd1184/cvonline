import { environment } from '../../environments/environment';

export class Constants {
  public static readonly DomainURL = environment.API;
}

export class ApiRoutes {
  public static readonly Cuisine = 'cuisines';
  public static readonly Ingredient = 'ingredients';
  public static readonly Country = 'countries';
  public static readonly Currency = 'currencies';
  public static readonly City = 'cities';
  public static readonly Ambiance = 'ambiances';
  public static readonly RestaurantType = 'restauranttypes';
  public static readonly DishType = 'dishtypes';
  public static readonly ExtraInfo = 'extrainfo';
  public static readonly Facility = 'facilities';
  public static readonly CookingMethod = 'cookingmethods';
  public static readonly Tenant = 'tenants';
  public static readonly Restaurant = 'restaurants';
}
