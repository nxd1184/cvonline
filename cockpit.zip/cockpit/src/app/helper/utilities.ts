export class Utility {
    /**
     * static log
    */
    public static log(data) {
        console.log(data);
    }

    public static transformToQueryString(obj: any, prefix: string = '') {
      const query = [];
      let param: any;

      for (param in obj) {
        if (obj.hasOwnProperty(param)) {
          const key = prefix ? prefix + '[' + param + ']' : param,
            value = obj[param];
          query.push((value !== null && typeof value === 'object') ?
            Utility.transformToQueryString(value, key) :
            key + '=' + value);
        }
      }
      return query.join('&');
    }
}
