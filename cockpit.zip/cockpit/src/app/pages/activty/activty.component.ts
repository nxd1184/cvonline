import { Component } from '@angular/core';

@Component({
  selector: 'app-activty',
  templateUrl: './activty.component.html',
  styleUrls: ['./activty.component.scss']
})
export class ActivtyComponent {
}
