import { Injectable } from '@angular/core';
import {BaseService} from './base.service';
import {HttpClient} from '@angular/common/http';

import {ApiRoutes} from '../helper';
import {Dish} from '../models/dish.model';
import {Observable} from 'rxjs/Observable';

@Injectable()
export class DishService extends BaseService {

  constructor(http: HttpClient) {
    super(http);
  }

  createDish(restaurant_id: number, dish: Dish): Observable<Dish> {
    return this.doPost(`${ApiRoutes.Restaurant}/` + restaurant_id + '/dishes', dish.toJson()).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.data;
    });
  }

}
