import { Injectable } from '@angular/core';
import {BaseService} from './base.service';
import {HttpClient} from '@angular/common/http';
import {ApiRoutes} from '../helper';
import {Observable} from 'rxjs/Observable';
import {Restaurant} from '../models/restaurant.model';

@Injectable()
export class RestaurantService extends BaseService {

  constructor(http: HttpClient) {
    super(http);
  }

  createRestaurant(tenant_id: number, restaurant: Restaurant): Observable<Restaurant> {
    return this.doPost(`${ApiRoutes.Tenant}/` + tenant_id + '/restaurants/', restaurant.toJson()).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.data;
    });
  }
}
