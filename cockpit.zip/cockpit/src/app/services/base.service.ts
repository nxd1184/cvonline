﻿﻿import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs/Observable";
import { Utility } from "../helper";
import "rxjs/add/operator/map";
import "rxjs/add/operator/catch";
import "rxjs/add/observable/throw";
import { environment } from "../../environments/environment";
@Injectable()
export class BaseService {
  protected domain = environment.API;
  private _tokenKey: string;

  constructor(private http: HttpClient) {}

  protected doGet(apiUrl: string, params?: string): Observable<any> {
    let header: HttpHeaders = new HttpHeaders();
    const url =
      params === undefined
        ? `${this.domain}/${apiUrl}`
        : `${this.domain}/${apiUrl}/${params}`;

    return this.http
      .get(url, { headers: header })
      .catch(this.handleError.bind(this));
  }

  protected doPost(apiUrl: string, data: any): Observable<any> {
    const bodyString = JSON.stringify(data);
    const header = this.createHeader();

    return this.http
      .post(`${this.domain}/${apiUrl}`, bodyString, { headers: header })
      .catch(this.handleError.bind(this));
  }

  protected doPostFileObject(apiUrl: string, data: any): Observable<any> {
    const formData = this.getModelAsFromData(data);
    this._tokenKey = localStorage.getItem("auth_token");
    const headers = new HttpHeaders();
    if (this._tokenKey !== undefined) {
      headers.append("Authorization", `${this._tokenKey}`);
    }
    return this.http
      .post(`${this.domain}/${apiUrl}`, formData, { headers: headers })
      .catch(this.handleError.bind(this));
  }

  protected doPostFile(apiUrl: string, data: any): Observable<any> {
    const header = this.createHeader("file");

    return this.http
      .post(`${this.domain}/${apiUrl}`, data, { headers: header })
      .catch(this.handleError.bind(this));
  }

  protected doPut(apiUrl: string, data: any): Observable<any> {
    const bodyString = JSON.stringify(data);
    const header = this.createHeader();

    return this.http
      .put(`${this.domain}/${apiUrl}`, bodyString, { headers: header })
      .catch(this.handleError.bind(this));
  }

  protected doDelete(apiUrl: string): Observable<any> {
    const header = this.createHeader();

    return this.http
      .delete(`${this.domain}/${apiUrl}`, { headers: header })
      .catch(this.handleError.bind(this));
  }

  protected handleError(error: any) {
    console.log("error status = " + error.status);
    alert(error.message);
    console.log(error);
    return Observable.throw(error);
  }

  private createHeader(type: string = ""): HttpHeaders {
    this._tokenKey = localStorage.getItem("auth_token");
    let contentType = "";
    let headers = {};

    if (this._tokenKey) {
      headers["Authorization"] = `${this._tokenKey}`;
    }

    switch (type) {
      case "":
      case "json":
        contentType = "application/json";
        break;
      case "authentication":
        contentType = "application/x-www-form-urlencoded";
        break;
      case "text":
        contentType = "text/plain";
        break;
      case "file":
        contentType = "";
        break;
    }

    if (contentType.length > 0) {
      headers["Content-Type"] = contentType;
    }

    return new HttpHeaders({
      ...headers
    });
  }

  private getModelAsFromData(data: any) {
    const dataAsFormData = new FormData();

    // create instance vars to store keys and final output
    const keyArr: any[] = Object.keys(data);

    // loop through the object,
    // pushing values to the return array
    keyArr.forEach((key: any) => {
      dataAsFormData.append(key, data[key]);
    });

    // return the resulting array
    return dataAsFormData;
  }
}
