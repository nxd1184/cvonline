import { Injectable } from '@angular/core';
import {BaseService} from './base.service';
import {HttpClient} from '@angular/common/http';

import {ApiRoutes} from '../helper';
import {Course} from '../models/course.model';
import {Observable} from 'rxjs/Observable';

@Injectable()
export class CourseService extends BaseService {


  constructor(http: HttpClient) {
    super(http);
  }

  createCourse(restaurant_id: number, course: Course): Observable<Course> {

    return this.doPost(`${ApiRoutes.Restaurant}/` + restaurant_id + '/menus', course.toJson(), ).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.data;
    });
  }

}
