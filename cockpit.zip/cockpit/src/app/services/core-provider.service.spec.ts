import { TestBed, inject } from "@angular/core/testing";

import { CoreProviderService } from "./core-provider.service";

describe("CoreProviderService", () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CoreProviderService]
    });
  });

  it("should be created", inject(
    [CoreProviderService],
    (service: CoreProviderService) => {
      expect(service).toBeTruthy();
    }
  ));
});
