import { Injectable } from '@angular/core';
import {BaseService} from './base.service';
import {HttpClient} from '@angular/common/http';
import {ApiRoutes} from '../helper';
import {Observable} from 'rxjs/Observable';
import {Tenant} from '../models/tenant.model';
import {Dish} from '../models/dish.model';

@Injectable()
export class TenantService extends BaseService {

  constructor(http: HttpClient) {
    super(http);
  }

  createTenant(tenant: Tenant): Observable<Tenant> {
    return this.doPost(`${ApiRoutes.Tenant}/`, tenant.toJson()).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.data;
    });
  }

  createDish(dish: Dish): Observable<boolean> {
    return this.doPost(`${ApiRoutes.Restaurant}/` + dish.restaurant_id + '/dishes/', dish.toJson()).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.data;
    });
  }
}
