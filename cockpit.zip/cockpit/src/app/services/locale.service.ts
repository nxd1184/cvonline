import {Injectable} from '@angular/core';
import {Localeable} from '../models/localeable.model';

@Injectable()
export class LocaleService {
  constructor() { }


  getLocales(): Localeable[] {
    return [
      {
        is_default: true,
        english_name: 'English',
        id: 'en'
      }
    ];
  }
}
