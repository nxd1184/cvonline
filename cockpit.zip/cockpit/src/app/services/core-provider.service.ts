import { Injectable } from "@angular/core";
import { BaseService } from "./base.service";
import { HttpClient } from "@angular/common/http";
import { SearchOption } from "../models/SearchOption";
import { Observable } from "rxjs/Observable";
import {
  Cuisine,
  Ingredient,
  City,
  Country,
  Ambiance,
  Facility,
  RestaurantType,
  DishType,
  CookingMethod
} from "../models/core-provider.model";
import { ApiRoutes } from "../helper";

@Injectable()
export class CoreProviderService extends BaseService {
  constructor(http: HttpClient) {
    super(http);
  }

  getMockCuisines(pageInfo) {
    return this.doGet("assets/data/cuisines.json").map(res => {
      let cuisines: Cuisine[] = [];
      let total = 0;

      if (res.success) {
        cuisines = res.data.items.map(json => new Cuisine().fromJson(json));
        cuisines = cuisines.slice(
          pageInfo.pageNumber * pageInfo.size,
          (pageInfo.pageNumber + 1) * pageInfo.size
        );
        total = res.data.total;
      } else {
        this.handleError(res);
      }

      const output: [number, Cuisine[]] = [total, cuisines];

      return output;
    });
  }

  getMockPlaces() {
    return this.doGet("assets/data/places.json");
  }

  getMockFacilities() {
    return this.doGet("assets/data/facilities.json");
  }

  getMockCourses() {
    return this.doGet("assets/data/courses.json");
  }

  getMockDishes() {
    return this.doGet("assets/data/dishes.json");
  }

  getCuisines(options: SearchOption): Observable<[number, Cuisine[]]> {
    return this.doGet(`${ApiRoutes.Cuisine}?${options.queryString}`).map(
      res => {
        let cuisines: Cuisine[] = [];
        let total = 0;

        if (res.success) {
          cuisines = res.data.items.map(json => new Cuisine().fromJson(json));
          total = res.data.total;
        } else {
          this.handleError(res);
        }

        const output: [number, Cuisine[]] = [total, cuisines];

        return output;
      }
    );
  }

  deleteCuisine(id: number): Observable<boolean> {
    return this.doDelete(`${ApiRoutes.Cuisine}/${id}`).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }

  createCuisine(cuisine: Cuisine): Observable<boolean> {
    return this.doPost(`${ApiRoutes.Cuisine}/`, cuisine.toJson()).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }

  updateCuisine(cuisine: Cuisine): Observable<boolean> {
    return this.doPut(
      `${ApiRoutes.Cuisine}/${cuisine.id}`,
      cuisine.toJson()
    ).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }

  // Ingredients
  getIngredients(options: SearchOption): Observable<[number, Ingredient[]]> {
    return this.doGet(`${ApiRoutes.Ingredient}?${options.queryString}`).map(
      res => {
        let ingredients = [];
        let total = 0;

        if (res.success) {
          ingredients = res.data.items.map(json =>
            new Ingredient().fromJson(json)
          );
          total = res.data.total;
        } else {
          this.handleError(res);
        }

        const output: [number, Ingredient[]] = [total, ingredients];

        return output;
      }
    );
  }

  createIngredient(ingredient: Ingredient): Observable<boolean> {
    return this.doPost(`${ApiRoutes.Ingredient}/`, ingredient.toJson()).map(
      res => {
        if (!res.success) {
          this.handleError(res);
        }

        return res.success;
      }
    );
  }

  updateIngredient(ingredient: Ingredient): Observable<boolean> {
    return this.doPut(
      `${ApiRoutes.Ingredient}/${ingredient.id}`,
      ingredient.toJson()
    ).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }

  deleteIngredient(id: number): Observable<boolean> {
    return this.doDelete(`${ApiRoutes.Ingredient}/${id}`).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }
  // End Ingredients

  // Countries
  getCountries(options: SearchOption): Observable<Country[]> {
    return this.doGet(`${ApiRoutes.Country}?${options.queryString}`).map(
      res => {
        let countries = [];

        if (res.success) {
          countries = res.data.items.map(json => new Country().fromJson(json));
        } else {
          this.handleError(res);
        }

        return countries;
      }
    );
  }

  createCountry(country: Country): Observable<boolean> {
    return this.doPost(`${ApiRoutes.Country}/`, country.toJson()).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }

  updateCountry(country: Country): Observable<boolean> {
    return this.doPut(
      `${ApiRoutes.Country}/${country.id}`,
      country.toJson()
    ).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }

  deleteCountry(id: number): Observable<boolean> {
    return this.doDelete(`${ApiRoutes.Country}/${id}`).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }
  // End Countries

  // Cities
  getCities(options: SearchOption): Observable<City[]> {
    return this.doGet(`${ApiRoutes.City}?${options.queryString}`).map(res => {
      let cities = [];

      if (res.success) {
        cities = res.data.items.map(json => new City().fromJson(json));
      } else {
        this.handleError(res);
      }

      return cities;
    });
  }

  createCity(city: City): Observable<boolean> {
    return this.doPost(`${ApiRoutes.City}/`, city.toJson()).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }

  updateCity(city: City): Observable<boolean> {
    return this.doPut(`${ApiRoutes.City}/${city.id}`, city.toJson()).map(
      res => {
        if (!res.success) {
          this.handleError(res);
        }

        return res.success;
      }
    );
  }

  deleteCity(id: number): Observable<boolean> {
    return this.doDelete(`${ApiRoutes.City}/${id}`).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }
  // End Cities

  // Ambiance
  getAmbiances(options: SearchOption): Observable<[number, Ambiance[]]> {
    return this.doGet(`${ApiRoutes.Ambiance}?${options.queryString}`).map(
      res => {
        let ambiances: Ambiance[] = [];
        let total = 0;

        if (res.success) {
          ambiances = res.data.items.map(json => new Ambiance().fromJson(json));
          total = res.data.total;
        } else {
          this.handleError(res);
        }

        const output: [number, Ambiance[]] = [total, ambiances];

        return output;
      }
    );
  }

  deleteAmbiance(id: number): Observable<boolean> {
    return this.doDelete(`${ApiRoutes.Ambiance}/${id}`).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }

  createAmbiance(ambiance: Ambiance): Observable<boolean> {
    return this.doPost(`${ApiRoutes.Ambiance}/`, ambiance.languages).map(
      res => {
        if (!res.success) {
          this.handleError(res);
        }

        return res.success;
      }
    );
  }

  updateAmbiance(ambiance: Ambiance): Observable<boolean> {
    return this.doPut(
      `${ApiRoutes.Ambiance}/${ambiance.id}`,
      ambiance.languages
    ).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }
  // End Ambiance

  // Facility
  getFacilities(options: SearchOption): Observable<[number, Facility[]]> {
    return this.doGet(`${ApiRoutes.Facility}?${options.queryString}`).map(
      res => {
        let facilities: Facility[] = [];
        let total = 0;
        if (res.success) {
          facilities = res.data.items.map(json =>
            new Facility().fromJson(json)
          );
          total = res.data.total;
        } else {
          this.handleError(res);
        }
        const output: [number, Facility[]] = [total, facilities];
        return output;
      }
    );
  }

  deleteFacility(id: number): Observable<boolean> {
    return this.doDelete(`${ApiRoutes.Facility}/${id}`).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }

  createFacility(facility: Facility): Observable<boolean> {
    return this.doPost(`${ApiRoutes.Facility}/`, facility.languages).map(
      res => {
        if (!res.success) {
          this.handleError(res);
        }

        return res.success;
      }
    );
  }

  updateFacility(facility: Facility): Observable<boolean> {
    return this.doPut(
      `${ApiRoutes.Facility}/${facility.id}`,
      facility.languages
    ).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }
  // End Facility

  // Restaurant type
  getRestaurantTypes(
    options: SearchOption
  ): Observable<[number, RestaurantType[]]> {
    return this.doGet(`${ApiRoutes.RestaurantType}?${options.queryString}`).map(
      res => {
        let restaurantTypes: RestaurantType[] = [];
        let total = 0;
        if (res.success) {
          restaurantTypes = res.data.items.map(json =>
            new RestaurantType().fromJson(json)
          );
          total = res.data.total;
        } else {
          this.handleError(res);
        }
        const output: [number, RestaurantType[]] = [total, restaurantTypes];
        return output;
      }
    );
  }

  deleteRestaurantType(id: number): Observable<boolean> {
    return this.doDelete(`${ApiRoutes.RestaurantType}/${id}`).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }

  createRestaurantType(restaurantType: RestaurantType): Observable<boolean> {
    return this.doPost(
      `${ApiRoutes.RestaurantType}/`,
      restaurantType.languages
    ).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }

  updateRestaurantType(restaurantType: RestaurantType): Observable<boolean> {
    return this.doPut(
      `${ApiRoutes.RestaurantType}/${restaurantType.id}`,
      restaurantType.languages
    ).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }

  // Dish type
  getDishTypes(options: SearchOption): Observable<[number, DishType[]]> {
    return this.doGet(`${ApiRoutes.DishType}?${options.queryString}`).map(
      res => {
        let dishTypes: DishType[] = [];
        let total = 0;
        if (res.success) {
          dishTypes = res.data.items.map(json => new DishType().fromJson(json));
          total = res.data.total;
        } else {
          this.handleError(res);
        }
        const output: [number, DishType[]] = [total, dishTypes];
        return output;
      }
    );
  }

  deleteDishType(id: number): Observable<boolean> {
    return this.doDelete(`${ApiRoutes.DishType}/${id}`).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }

  createDishType(dishType: DishType): Observable<boolean> {
    return this.doPost(`${ApiRoutes.DishType}/`, dishType.languages).map(
      res => {
        if (!res.success) {
          this.handleError(res);
        }

        return res.success;
      }
    );
  }

  updateDishType(dishType: DishType): Observable<boolean> {
    return this.doPut(
      `${ApiRoutes.DishType}/${dishType.id}`,
      dishType.languages
    ).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }
  // End Dish type

  // Cooking Method
  getCookingMethods(options: SearchOption): Observable<[number, CookingMethod[]]> {
    return this.doGet(`${ApiRoutes.CookingMethod}?${options.queryString}`).map(
      res => {
        let cookingMethods: CookingMethod[] = [];
        let total = 0;

        if (res.success) {
          cookingMethods = res.data.items.map(json => new CookingMethod().fromJson(json));
          total = res.data.total;
        } else {
          this.handleError(res);
        }

        const output: [number, CookingMethod[]] = [total, cookingMethods];

        return output;
      }
    );
  }

  deleteCookingMethod(id: number): Observable<boolean> {
    return this.doDelete(`${ApiRoutes.CookingMethod}/${id}`).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }

  createCookingMethod(cookingMethod: CookingMethod): Observable<boolean> {
    return this.doPost(`${ApiRoutes.CookingMethod}/`, cookingMethod.languages).map(
      res => {
        if (!res.success) {
          this.handleError(res);
        }

        return res.success;
      }
    );
  }

  updateCookingMethod(cookingMethod: CookingMethod): Observable<boolean> {
    return this.doPut(
      `${ApiRoutes.CookingMethod}/${cookingMethod.id}`,
      cookingMethod.languages
    ).map(res => {
      if (!res.success) {
        this.handleError(res);
      }

      return res.success;
    });
  }
  // End Cooking Method
}
