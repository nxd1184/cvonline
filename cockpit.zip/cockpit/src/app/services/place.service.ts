import { Injectable } from '@angular/core';
import {Tenant} from '../models/tenant.model';
import {Dish} from '../models/dish.model';
import {Restaurant} from '../models/restaurant.model';

@Injectable()
export class PlaceService {
  tenant: Tenant;
  restaurant: Restaurant;
  dish: Dish;

  constructor() { }


  removeTenant() {
    this.tenant = null;
  }
}
