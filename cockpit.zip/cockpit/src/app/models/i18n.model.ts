import {Language} from './language.model';

export class I18N {
  texts: Language[] = [];
}
