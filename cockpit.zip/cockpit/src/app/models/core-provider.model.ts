import { Localeable } from './localeable.model';

export class CoreProvider extends Localeable {
  id: number = 0;
  name: string = '';
  slug: string = '';

  fromJson(json: any) {
    if (json) {
      this.id = json.id;
      this.slug = json.slug;
      this.name = json.name;
      this.languages = json.languages;
    }

    return this;
  }

  toJson() {
    return this.languages;
  }
}

export class Cuisine extends CoreProvider {
  parents: number[] = [];

  fromJson(json: any) {
    super.fromJson(json);

    if (json) {
      this.parents = json.parents;
    }

    return this;
  }

  toJson() {
    const json = super.toJson();
    (json as any).parents = this.parents;

    return json;
  }
}

export class Ingredient extends CoreProvider {
  parents: number[] = [];

  fromJson(json: any) {
    super.fromJson(json);

    if (json) {
      this.parents = json.parents;
    }

    return this;
  }

  toJson() {
    const json = super.toJson();
    (json as any).parents = this.parents;

    return json;
  }
}

export class City extends CoreProvider {
  country_id: number;

  fromJson(json: any) {
    super.fromJson(json);

    if (json) {
      this.country_id = json.country_id;
    }

    return this;
  }

  toJson() {
    const json = super.toJson();
    (json as any).country_id = this.country_id;

    return json;
  }
}

export class Country extends CoreProvider { }
export class CookingMethod extends CoreProvider { }
export class Ambiance extends CoreProvider { }
export class Facility extends CoreProvider { }
export class RestaurantType extends CoreProvider { }
export class DishType extends CoreProvider { }
