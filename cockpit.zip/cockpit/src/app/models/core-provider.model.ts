import { Localeable } from './localeable.model';
import {I18N} from './i18n.model';

export class CoreProvider {
  id = 0;
  name: any;
  slug = '';
  languages: any;

  default(): CoreProvider {
    delete this.id;
    delete this.slug;
    this.name = new I18N();
    return this;
  }

  fromJson(json: any) {
    if (json) {
      this.id = json.id;
      this.slug = json.slug;
      this.name = json.name;
    }

    return this;
  }

  toJson() {
    return this;
  }
}

export class Cuisine extends CoreProvider {
  parents: number[] = [];

  fromJson(json: any) {
    super.fromJson(json);

    if (json) {
      this.parents = json.parents;
    }

    return this;
  }

  toJson() {
    const json = super.toJson();
    (json as any).parents = this.parents;

    return json;
  }
}

export class Ingredient extends CoreProvider {
  parents: number[] = [];

  fromJson(json: any) {
    super.fromJson(json);

    if (json) {
      this.parents = json.parents;
    }

    return this;
  }

  toJson() {
    const json = super.toJson();
    (json as any).parents = this.parents;

    return json;
  }
}

export class City extends CoreProvider {
  country_id: number;

  fromJson(json: any) {
    super.fromJson(json);

    if (json) {
      this.country_id = json.country_id;
    }

    return this;
  }

  toJson() {
    const json = super.toJson();
    (json as any).country_id = this.country_id;

    return json;
  }
}

export class Currency extends CoreProvider {
  symbol: string;
  code: string;
  fractional_unit: string;
  number_to_basic: number;

  fromJson(json: any) {
    super.fromJson(json);

    if (json) {
      this.symbol = json.symbol;
      this.code = json.code;
      this.fractional_unit = json.fractional_unit;
      this.number_to_basic = json.number_to_basic;
    }

    return this;
  }

  toJson() {
    const json = super.toJson();
    (json as any).symbol = this.symbol;
    (json as any).code = this.code;
    (json as any).fractional_unit = this.fractional_unit;
    (json as any).number_to_basic = this.number_to_basic;

    return json;
  }
}

export class Country extends CoreProvider { }
export class CookingMethod extends CoreProvider { }
export class Ambiance extends CoreProvider { }
export class Facility extends CoreProvider { }
export class RestaurantType extends CoreProvider { }
export class DishType extends CoreProvider { }
export class ExtraInfo extends CoreProvider { }
