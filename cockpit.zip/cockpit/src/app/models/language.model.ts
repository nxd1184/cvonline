export class Language {
  display_text: string;
  locale_id: string;

  fromJson(json: any) {
    if (json) {
      this.display_text = json.display_text;
      this.locale_id = json.locale_id;
    }
    return this;
  }

  toJson() {
    return this;
  }
}
