export class Language {
  language: string;
  value: string;

  fromJson(json: any) {
    if (json) {
      this.language = json.language;
      this.value = json.value;
    }
    return this;
  }

  toJson() {
    return this;
  }
}
