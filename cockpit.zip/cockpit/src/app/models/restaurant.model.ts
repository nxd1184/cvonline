import {Introduction} from './introduction.model';

export class Restaurant {
  introductions: Array<Introduction>;
  long_name: string;
  phone_number: string;
  email: string;
  price_level: number;
  restaurant_type_ids: number[];
  cuisine_ids: number[];
  address: string;
  country_id: number;
  city_id: number;
  post_code: string;
  longitude: number;
  latitude: number;
  opening_hours: OpeningHours;
  social_info: SocialInfo;

  fromJson(json: any): Restaurant {
    if (json) {
      this.introductions = json.introductions;
      this.long_name = json.long_name;
      this.phone_number = json.phone_number;
      this.email = json.email;
      this.price_level = json.price_level;
      this.restaurant_type_ids = json.restaurant_type_ids;
      this.cuisine_ids = json.cuisine_ids;
      this.address = json.address;
      this.country_id = json.country_id;
      this.city_id = json.city_id;
      this.post_code = json.post_code;
      this.longitude = json.longitude;
      this.latitude = json.latitude;
      this.opening_hours = new OpeningHours().fromJson(json.opening_hours);
      this.social_info = new SocialInfo().fromJson(json.social_info);
    }
    return this;
  }

  toJson() {
    return this;
  }
}

export class OpeningHours {
  is_specific_time: boolean;
  no_hours_available: boolean;
  hours: Hours;

  fromJson(json: any): OpeningHours {
    if (json) {
      this.is_specific_time = json.is_specific_time;
      this.no_hours_available = json.no_hours_available;
      this.hours = new Hours().fromJson(json.hours);
    }
    return this;
  }
}

export class Hours {
  monday: TimeRange[];
  tuesday: TimeRange[];
  wednesday: TimeRange[];
  thursday: TimeRange[];
  friday: TimeRange[];
  saturday: TimeRange[];
  sunday: TimeRange[];

  fromJson(json: any): Hours {
    if (json) {
      if (json.monday.selected ) {
        this.monday = json.monday.ranges.map(value => new TimeRange().fromJson(value));
      } else {
        this.monday = [];
      }

      if (json.tuesday.selected ) {
        this.tuesday = json.tuesday.ranges.map(value => new TimeRange().fromJson(value));
      } else {
        this.tuesday = [];
      }

      if (json.wednesday.selected ) {
        this.wednesday = json.wednesday.ranges.map(value => new TimeRange().fromJson(value));
      } else {
        this.wednesday = [];
      }

      if (json.thursday.selected ) {
        this.thursday = json.thursday.ranges.map(value => new TimeRange().fromJson(value));
      } else {
        this.thursday = [];
      }

      if (json.friday.selected ) {
        this.friday = json.friday.ranges.map(value => new TimeRange().fromJson(value));
      } else {
        this.friday = [];
      }

      if (json.saturday.selected ) {
        this.saturday = json.saturday.ranges.map(value => new TimeRange().fromJson(value));
      } else {
        this.saturday = [];
      }

      if (json.sunday.selected ) {
        this.sunday = json.sunday.ranges.map(value => new TimeRange().fromJson(value));
      } else {
        this.sunday = [];
      }

      // this.tuesday = json.tuesday.map(value => new TimeRange().fromJson(value));
      // this.wednesday = json.wednesday.map(value => new TimeRange().fromJson(value));
      // this.thursday = json.thursday.map(value => new TimeRange().fromJson(value));
      // this.friday = json.friday.map(value => new TimeRange().fromJson(value));
      // this.saturday = json.saturday.map(value => new TimeRange().fromJson(value));
      // this.sunday = json.sunday.map(value => new TimeRange().fromJson(value));
    }
    return this;
  }
}

export class TimeRange {
  start: string;
  end: string;

  fromJson(json: any): TimeRange {
    if (json) {
      this.start = '1900-01-01 ' + json.start;
      this.end = '1900-01-01 ' + json.end;
    }
    return this;
  }
}

export class SocialInfo {
  facebook: string;
  instagram: string;
  website: string;
  linkedin: string;
  twitter: string;
  other: string;

  fromJson(json: any): SocialInfo{
    if (json) {
      this.facebook = json.facebook;
      this.instagram = json.instagram;
      this.website = json.website;
      this.linkedin = json.linkedin;
      this.twitter = json.twitter;
      this.other = json.other;
    }
    return this;
  }
}
