import {Introduction} from './introduction.model';

export class Restaurant {
  introductions: Array<Introduction>;
  long_name: string;
  phone_number: string;
  email: string;

  fromJson(json: any) {
    if (json) {
      this.introductions = json.introductions;
      this.long_name = json.long_name;
      this.phone_number = json.phone_number;
      this.email = json.email;
    }
    return this;
  }

  toJson() {
    return this;
  }
}
