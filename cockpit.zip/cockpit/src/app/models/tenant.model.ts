export class Tenant {
  id: number;
  tenancy_name: string;
  status: number;
  phone_number: string;
  email: string;
  owner_id: string;
  owner_name: string;

  fromJson(json: any) {
    if (json) {
      this.id = json.id;
      this.tenancy_name = json.tenancy_name;
      this.status = json.status;
      this.phone_number = json.phone_code + json.phone_number;
      this.email = json.email;
      this.owner_name = json.owner_name;
      this.owner_id = json.owner_id;
    }

    return this;
  }

  toJson() {
    return this;
  }
}
