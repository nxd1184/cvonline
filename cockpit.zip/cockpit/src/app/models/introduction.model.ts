import {TimeRange} from './restaurant.model';

export class Introduction {
  texts: Array<Language>;
  fromJson(json: any): Introduction {
    if (json) {
      this.texts = json.map(value => new Language().fromJson(value));
    }
    return this;
  }
  toJson() {
    return this;
  }
}

export class Language {
  display_text: string;
  locale_id: string;
  fromJson(json: any) {
    if (json) {
      this.display_text = json.value;
      this.locale_id = json.language;
    }
    return this;
  }

  toJson() {
    return this;
  }
}
