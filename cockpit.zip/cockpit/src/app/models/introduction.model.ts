export class Introduction {
  language: string;
  value: number;

  fromJson(json: any) {
    if (json) {
      this.language = json.language;
      this.value = json.value;
    }
    return this;
  }

  toJson() {
    return this;
  }
}
