import { Utility } from "../helper";

export class SearchOption {
  sort = true;
  direction = SEARCH_DIRECTION.ASC;
  limit = 100;
  offset = 0;
  language = "en";
  allLanguage = true;

  get queryString() {
    return Utility.transformToQueryString(this.toJson());
  }

  toJson() {
    return {
      sort: this.sort ? 1 : 0,
      direction: this.direction,
      limit: this.limit,
      offset: this.offset,
      language: this.language,
      all_language: this.allLanguage ? 1 : 0
    };
  }
}

export const SEARCH_DIRECTION = {
  ASC: "asc",
  DESC: "desc"
};
