export class Price {
  currency_id: number;
  price: number;

  fromJson(json: any) {
    if (json) {
      this.currency_id = json.currency_id;
      this.price = json.price;
    }
    return this;
  }

  toJson() {
    return this;
  }
}
