export class Localeable {
    languages: any;
}