export class Localeable {
  is_default: boolean = false;
  english_name: string = '';
  id: string = '';
}
