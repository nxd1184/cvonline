import {Dish} from './dish.model';

export class Course {
  id: number;
  name: string;
  restaurant_id: number;
  media_ref: string;
  order: number;
  creation_date: Date;
  modification_date: Date;
  dishes: Array<Dish>



  fromJson(json: any) {
    if (json) {
      this.id = json.id;
      this.name = json.name;
      this.media_ref = json.media_ref;
      this.order = json.order;
      this.creation_date = json.creation_date;
      this.modification_date = json.modification_date;
      this.dishes = json.dishes;
    }

    return this;
  }

  toJson() {
    return this;
  }
}
