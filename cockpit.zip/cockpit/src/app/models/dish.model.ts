import {Language} from './language.model';
import {Price} from './price.model';

export class Dish {
  id: number;
  name: string;
  descriptions: Array<Language>;
  media_ref: string;
  cooking_method_ids: Array<number>;
  ingredient_ids: Array<number>;
  extra_info_ids: Array<number>;
  dish_type_ids: Array<number>;
  prices: Array<Price>;
  restaurant_id: number;

  fromJson(json: any) {
    if (json) {
      this.id = json.id;
      this.name = json.name;
      this.descriptions = json.descriptions;
      this.media_ref = json.media_ref;
      this.cooking_method_ids = json.cooking_method_ids;
      this.ingredient_ids = json.ingredient_ids;
      this.extra_info_ids = json.extra_info_ids;
      this.dish_type_ids = json.dish_type_ids;
      this.prices = json.prices;
    }

    return this;
  }

  toJson() {
    return this;
  }
}
