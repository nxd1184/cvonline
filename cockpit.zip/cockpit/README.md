Repo for Cockpit

# GIT BRANCHING CONVENTION
```
Always create new branch from development branch

* Branch name

Feature task: features/briefly_feature_description
Development bugs: bugs/briefly_bug_description
Production bugs: hotfixs/briefly_bug_description
```
