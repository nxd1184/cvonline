import { DecimaPage } from './app.po';

describe('decima App', () => {
  let page: DecimaPage;

  beforeEach(() => {
    page = new DecimaPage();
  });

  it('should expect true to be true', () => {
    expect(true).toBe(true);
  });
});
